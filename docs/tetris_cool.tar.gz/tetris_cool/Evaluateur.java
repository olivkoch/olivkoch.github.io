/* Erell Jamelot & Olivier Koch */

public class Evaluateur
{
    public Position maPosition;
    public TetrisPiece maPiece;
    public Grid maGrille_old;

    public Evaluateur (Grid G) {
	maGrille_old = new Grid(G);

    }

    public Evaluateur (Tetris T) {
	maGrille_old = new Grid(T.game.playfield); 
    }

    public void setGrid (Grid g) {
	maGrille_old = g;
    }
    
    public void setPiece (TetrisPiece p) {
	maPiece = p;
    }
    

    public void affiche (Grid g)
    {
	String l;
	for (int j=0;j<g.y;j++) {
	    l="";
	    for (int i=0;i<g.x;i++) {
		l=l+" "+g.grid[i][j];
	    }
	    l=l+"   "+NombreTrousLigne(g,j);
	    System.out.println(l);
	}
    }
    
    /**
     * dans la grille G, trouve le niveau du trou le plus profond 
     * qui n'est pas une cave
     * (donc avec la numerotation, la case ouverte de j le plus grand) 
     */
    private int PlusBas(Grid G)
    {
	int hauteur_trou;
	int stop, h;
	stop=0;
	hauteur_trou=0;
	for (int i=0;i<G.x;i++)
	    { 
		h=0; stop=0;
		for (int j=1;(j<G.y)&&(stop==0);j++)
		    {
			h++;
			if (G.grid[i][j]!=0) stop =1;
		    }
		if (h>hauteur_trou) hauteur_trou=h;
	    }
	if (stop==1) hauteur_trou--;
	return hauteur_trou;
    }
    
    /**
     * dans la grille G, trouve le niveau de la case la plus haute 
     * (donc avec la numerotation, la case pleine de j le plus petit) 
     */

private int PlusHaut(Grid G)
    {
        int i=0;
	int j=0;
        int hauteur_max=0;

        while ((j<G.y)&&(hauteur_max==0)) {
            while ((i<G.x)&&(hauteur_max==0))
		{
		    if (G.grid[i][j]!=0) hauteur_max=j;
		    i++;
		}
	    j++; i=0;
        }
	if (hauteur_max==0) hauteur_max=G.y-1;
        return(hauteur_max);
    }
    

   

    /**
     * dans la grille G, renvoie le nombre de trous de la ligne j
     */
    private int NombreTrousLigne(Grid G, int j)
    {
        int n=0;
        for(int i=0;i<G.x;i++) {
            if(G.grid[i][j]==0) n++;
	}
        return n ;
    }
    /**
     * dans la grille G, renvoie le nombre de trous caches de la colonne i
     */
    private int NombreTrousCachesColonne(Grid G, int i)
    {
        int n=0;
	int go=0;
	for (int j=0;j<G.y;j++)
	    {
		if (G.grid[i][j]!=0) go++;
		if ( (go>0)&&(G.grid[i][j]==0) ) n++;
	    }
	return n;
    }

     private int hauteurColonne(Grid G, int i)
    {
	int h=0;
	int stop=0;
	while ((h<G.y)&&(stop==0))
	    {
		if (G.grid[i][h]!=0) stop=1;
		h++;
	    }
	return h;
    }

    public int poidsColonne(Grid G, int i)
    {
	int n=0;
	int go=0;
	for (int j=0;j<G.y;j++)
	    {
		if (G.grid[i][j]!=0) go++;
		if ( (go>0)&&(G.grid[i][j]==0) ) n++;
	    }
	if (n>0) return go;
	else return 0;
	
    }

    public int abs (int a)
    {
	if (a<=0) return -a;
	else return a;
    }


    public int notation(Grid Grille, Grid Grille2, int nbLignes) 
    {
        //0=ligne la plus haute et colonne la plus a gauche
	int ph1,ph2;
	int pb1,pb2;
        int trousCaches, trousCaches2;
	int trousLigne, trousLigne2;
	int poids;
	int Note=0;
	int a1=1; int a2=3; int a3=8; int a4=2; int a5=4; int a6=1; int a7=4; 

	pb1=PlusBas(Grille);
        pb2=PlusBas(Grille2);
        ph1=PlusHaut(Grille);
	ph2=PlusHaut(Grille2);

	trousLigne=NombreTrousLigne(Grille,pb1);
	trousLigne2=NombreTrousLigne(Grille2,pb1);

        //on regarde si la piece a cree des trous caches
	int Nbtrous=0;
	for(int i=0;i<Grille.x;i++)
            {
		poids = poidsColonne(Grille2,i);
		trousCaches=NombreTrousCachesColonne(Grille,i);
		trousCaches2=NombreTrousCachesColonne(Grille2,i);
		Nbtrous=Nbtrous+(trousCaches2-trousCaches);

                if(trousCaches2>trousCaches)
                    {
			//here : on a cree des trous
			Note=Note+a1*(ph2-ph1); //malus si on fait monter le niveau
			Note=Note+a2*(trousLigne-trousLigne2); //bonus si on supprime les trous du dernier niveau
			if (pb2-ph2<a7+1) Note=Note+a3*(trousCaches-trousCaches2);  //malus si ajout de trous
			else{ 
			    //here : on est en zone critique
			    //les trous sont mieux toleres
			    int compteur=0;
			    for (int j=0;j<Grille.y;j++){

				compteur=compteur+NombreTrousLigne(Grille,j)-NombreTrousLigne(Grille2,j);
			    }
			    if (pb2-ph2<Grille.y-4) 
				{
			    Note=Note+(int)(compteur/6*a4); // bonus si supprime le nb moyen de trous par lignes
			    Note=Note+(int)(a5*(ph2-ph1)); //malus si on fait monter le niveau
			    Note=Note+a2*(trousLigne-trousLigne2); //bonus si on supprime les trous du dernier niveau 
			    Note=Note+poids*ph2/compteur*(trousCaches-trousCaches2+1);  //malus si ajout de trous
				}
			    else
				{
				    //here : on est en zone super-critique !!!
				    Note=Note+(int)(4*a5*(ph2-ph1)); // super-malus si on fait monter le niveau
				    Note=Note+(int)(compteur/6*a4); // bonus si supprime le nb moyen de trous par lignes
				    Note=Note+4*a2*(trousLigne-trousLigne2); //mega-bonus si on supprime les trous du dernier niveau 
				}
			}
                    }     
            }
        if(Nbtrous==0)//pas de trous caches crees
            {  
		Note=Note+(a1*2)*(ph2-ph1); //malus si on fait monter le niveau
		trousLigne=NombreTrousLigne(Grille,pb1);
		trousLigne2=NombreTrousLigne(Grille2,pb1);
		Note=Note+(a2+1)*(trousLigne-trousLigne2); //bonus si on supprime les trous du dernier niveau
		if (pb2-ph2>a7+1) 
		    {
				//here : on est en zone critique
			//les augmentations de niveau sont moins toleres
			Note=Note+(int)(a6*(ph2-ph1)); //malus si on fait monter le niveau
			Note=Note+a2*(trousLigne-trousLigne2); //bonus si on supprime les trous du dernier niveau
		    }
		

	    }
	//here : bonus si on calcule le denivele moyen entre deux colonnes successives
	int compteur2=0;
	for (int k=0;k<Grille.x-1;k++)
	    {
		compteur2=compteur2+abs(hauteurColonne(Grille,k)-hauteurColonne(Grille,k+1))-abs(hauteurColonne(Grille2,k)-hauteurColonne(Grille2,k+1));
		
	    }

	Note=Note+(int)(compteur2/2); // bonus si on diminue le denivele moyen entre deux colonnes successives
	Note=Note+3*nbLignes*Grille.x; //bonus si on fait des lignes
	return(Note);
    }
    



    public Position evalue (Position p) {
	intNonZero testNonZero;
	intOr putDown;
	Grid maGrille_new;
	Position pEvaluee;
	int py=0;
	int nbLignes = 0;
	pEvaluee = new Position (p);
	testNonZero = new intNonZero();
	putDown = new intOr();
	maGrille_new = new Grid (maGrille_old);	
	
	while ((!maGrille_new.compare(maPiece,p.x,py+1,testNonZero))&&(py<maGrille_new.y-maPiece.y)) py++;
	maGrille_new.put_on(maPiece,p.x,py,putDown);
	  
	for(int j=maGrille_new.y-1;j>=0;j--)
	    while(testFullLine(j, maGrille_new)==true) {
		deleteLine(j, maGrille_new);
		nbLignes++;
	    }
	



	pEvaluee.score = notation (maGrille_old, maGrille_new, nbLignes);
	
	return pEvaluee;
    }

    private boolean testFullLine(int y, Grid field) {
	for (int i=0;i<field.x;i++) {
	    if (field.grid[i][y]==0) return false;
	}
	return true;
    }
    
    private void deleteLine(int y, Grid field) {
	for(int j=y;j>0;j--) {
	    for (int i=0;i<field.x;i++) field.grid[i][j]=field.grid[i][j-1];
	    for (int i=0;i<field.x;i++) field.grid[i][0]=0;
	}
    }




}

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *  A class to draw a box with a score in it.
 */

class ScoreBox extends JPanel implements PosPaintable {
    String message;
    int score;
    

    public ScoreBox(String initMessage)
	{
        message=initMessage;
	}

    public void setScore(int newScore)
	{
	score=newScore;
	}

    public void paint(Graphics g, int sx, int sy)
	{
	int x,y;
	FontMetrics fm;
	String msg;

	
	fm=g.getFontMetrics();
	msg=message+score;
	y=fm.getHeight();
	x=fm.stringWidth(msg);

	g.setColor(Color.white);
        g.fillRect(sx,sy,x+5,y+5);
	g.setColor(Color.black);
	g.drawString(msg,sx+5,sy+5+y/2);
	}
}

public class IA implements Runnable {
    
    public Tetris unePartieDeTetris; // pour pouvoir acqu�rir les donn�es et agir sur le jeu
    public Grid maGrille;            // copie de la grille courante pour les calculs
    public TetrisPiece maPiece;      // copie de la pi�ce courante pour les calculs
    
    public Effecteur monEffecteur;          // classe charg�e d'effectuer le coup retenu
    //public CalculIntervalle monIntervalle;  // classe charg�e de calculer les intervalles de mobilit�
    public Evaluateur monEvaluateur;        // classe charg�e de noter une position
    
    public IA (Tetris unJeuDeTetris) { // constructeur
	unePartieDeTetris = unJeuDeTetris;
	maGrille=new Grid(1,1);
	maPiece=new TetrisPiece();
	
	//monIntervalle = new CalculIntervalle (unePartieDeTetris);
	//new Thread(monIntervalle).start();

	monEvaluateur = new Evaluateur (maGrille);      // cr�ation de la classe Evaluateur
	monEffecteur=new Effecteur(unePartieDeTetris);  // cr�ation de la classe Effecteur
    }
    
    public void run () {
	nouvellePiece(); // lance les calculs...
	
	while (!unePartieDeTetris.gameOver) {       // tant que le jeu n'est pas fini...
	    while(!unePartieDeTetris.game.tombee) { // tant que la piece n'est pas tombee...
		try {
		    Thread.sleep(300);              // attente...
		} catch (InterruptedException  iexc) {
		    System.out.println("Erreur Stratege.nouvellePiece iexc : " + iexc);
		}
	    }
	  
	    unePartieDeTetris.game.initTombee();  // la piece est tombee, on initialise l'espion "tombee"
	    nouvellePiece();                      // lance les calculs...
	}
    }
    
    public void nouvellePiece() { // r�partition des calculs, notation et action
	int i,j;
	int compteur;
	int droite, gauche;
	Position[] tabPositions;
	tabPositions = new Position [48];

	maGrille=unePartieDeTetris.getGrid();        // initialisation de la grille de calculs...
	maPiece=unePartieDeTetris.getTetrisPiece();  //r�cup�ration de la pi�ce courante...

	//monIntervalle.setGrid   (maGrille);          // on initialise la grille de CalculIntervalle
	//monIntervalle.setPiece  (maPiece);           // on initialise la pi�ce de CalculIntervalle

	//gauche =0;//monIntervalle.getLeft();
	//droite = maGrille.x-maPiece.x;//monIntervalle.getRight();


	// distribue les calculs suivant toutes les positions possibles...
	monEvaluateur.setGrid (maGrille);
	TetrisPiece tmpPiece = new TetrisPiece(maPiece);
	compteur = 0;

	for (j=0;j<tmpPiece.nbRotation;j++) {
	    for (i=0;i<=maGrille.x-tmpPiece.x;i++) {
		
		monEvaluateur.setPiece (tmpPiece);
		tabPositions[compteur] = monEvaluateur.evalue (new Position (i,j)); //on r�cup�re une position not�e
	
		compteur++;
	    }
	    tmpPiece.rotate_cw();
	}
	
	// choix de la meilleure position
	int scoreMax=-10;
	int choix = 0;

	for (i=0;i<compteur;i++) {
	    if (tabPositions[i].score>=scoreMax) {
		scoreMax = tabPositions[i].score;
		choix = i;
	    }
	}
		
	monEffecteur.effectue(tabPositions[choix]); // effectue le meilleur coup...
	
    }
}

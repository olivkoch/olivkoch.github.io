public class Position {
    public int x;      // abscisse
    public int theta;  // orientation
    public int score;  // note de cette position
    
    public Position() {                   // constructeur
	x=0;
	theta=0;
	score=0;
    }
    
    public Position (Position p) {        // constructeur
	x = p.x;
	theta = p.theta;
	score = 0;
    }
    
    public Position(int x0, int theta0) { // constructeur
	x=x0;
	theta=theta0;
	score=0;
    }
}

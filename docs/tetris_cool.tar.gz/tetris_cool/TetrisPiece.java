import java.lang.*;

public class TetrisPiece extends Grid {
    
    public int nbRotation; // nombre de rotations diff�rentes inh�rentes � la pi�ce
    static Grid pieces[]= new Grid[7];
    static {
	pieces[0]= new Grid(3,2); // T
	pieces[0].grid[1][0]=2;
	pieces[0].grid[0][1]=2;
	pieces[0].grid[1][1]=2;
	pieces[0].grid[2][1]=2;
	pieces[0].grid[0][0]=0;
	pieces[0].grid[2][0]=0;

	pieces[1]= new Grid(2,2); // Carr�
	pieces[1].grid[0][0]=3;
	pieces[1].grid[1][0]=3;
	pieces[1].grid[0][1]=3;
	pieces[1].grid[1][1]=3;
	
	pieces[2]= new Grid(2,3); // Escalier descendant
	pieces[2].grid[0][0]=4;
	pieces[2].grid[0][1]=4;
	pieces[2].grid[0][2]=0;
	pieces[2].grid[1][0]=0;
	pieces[2].grid[1][1]=4;
	pieces[2].grid[1][2]=4;
	
	
	pieces[3]= new Grid(2,3); // Escalier ascendant
	pieces[3].grid[0][0]=0;
	pieces[3].grid[0][1]=5;
	pieces[3].grid[0][2]=5;
	pieces[3].grid[1][0]=5;
	pieces[3].grid[1][1]=5;
	pieces[3].grid[1][2]=0;

	pieces[4]= new Grid(3,2); // L droite
	pieces[4].grid[0][0]=0;
	pieces[4].grid[1][0]=0;
	pieces[4].grid[2][0]=6;
	pieces[4].grid[0][1]=6;
	pieces[4].grid[1][1]=6;
	pieces[4].grid[2][1]=6;
	
	pieces[5]= new Grid(3,2); // L gauche
	pieces[5].grid[0][0]=8;
	pieces[5].grid[1][0]=0;
	pieces[5].grid[2][0]=0;
	pieces[5].grid[0][1]=8;
	pieces[5].grid[1][1]=8;
	pieces[5].grid[2][1]=8;
	
	pieces[6]= new Grid(1,4); // Barre
	pieces[6].grid[0][0]=7;
	pieces[6].grid[0][1]=7;
	pieces[6].grid[0][2]=7;
	pieces[6].grid[0][3]=7;
    }
    
    TetrisPiece(int i)
    {
	super(pieces[i]);
	if (i==6) nbRotation = 2;
	if (i==5) nbRotation = 4;
	if (i==4) nbRotation = 4;
	if (i==3) nbRotation = 2;
	if (i==2) nbRotation = 2;
	if (i==1) nbRotation = 0;
	if (i==0) nbRotation = 4;
    }
    
    TetrisPiece()
    {
	this((int)(Math.random()*7.0));
	//this(3);
    }

    TetrisPiece(TetrisPiece p)
    {
	super(p);
	if (p.nbRotation==6) nbRotation = 2;
	if (p.nbRotation==5) nbRotation = 4;
	if (p.nbRotation==4) nbRotation = 4;
	if (p.nbRotation==3) nbRotation = 2;
	if (p.nbRotation==2) nbRotation = 2;
	if (p.nbRotation==1) nbRotation = 0;
	if (p.nbRotation==0) nbRotation = 4;
    }
    
}


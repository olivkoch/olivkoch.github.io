public class Principal { 

   public static void main(String[] args) { 
       System.out.println(" Entree dans un monde fantastique ");
       Tetris monTetris = new Tetris(); 
       IA monIA = new IA(monTetris); 

       // je d�marre le thread de l'objet monTetris
       new Thread(monTetris).start();
       
       // je d�marre le thread de l'objet monAgentJoueur 
       new Thread(monIA).start(); 

       System.out.println(" Sortie du monde des r�ves "); 
   } 

} 

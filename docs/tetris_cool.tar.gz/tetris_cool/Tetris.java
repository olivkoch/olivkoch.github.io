// passage de l'applet a une application: Lachiheb et Guiguet

import java.lang.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;




public class Tetris extends JPanel implements Runnable, KeyListener {
  /** the state of the game  */
  TetrisGame game;
  /** the game loop thread */
  Thread gameRunner;
  /** Size of the display area */
  int xs,ys;
  int x,y;
  ScoreBox box;
  boolean gameOver;

  /**
   * Overrides init() in java.applet.Applet
   * Parses attributes, initializes variables, 
   * calls resize() and getfocus().
   */
    public Tetris()
    {
	this.init();
	this.start();
    }

public void init()
  {

    System.out.println("Class string:"+toString());
        
    /*    try {
	  x=Integer.parseInt(getParameter("X"));
	  } catch (NullPointerException e) { x=10; }
	  catch (NumberFormatException e) { x=10; }
	  
	  try {
	  y=Integer.parseInt(getParameter("Y"));
      } catch (NullPointerException e) { y=20; }
      catch (NumberFormatException e) { y=20; }
    */   
    
    x=12;
    y=22;
    game=new TetrisGame(x,y,false);
    box=new ScoreBox("Score: ");
    xs=x*10+16;  // Play area
    ys=y*10+4   // Play area
      +60;    // Score box
    //resize(xs,ys);
    //requestFocus();
    this.setPreferredSize(new Dimension(400,600)); 
    
    JFrame fenetre = new JFrame("TETRIS");
    Container affichage = fenetre.getContentPane();  
    FlowLayout disposition = new FlowLayout();
    affichage.setLayout(disposition);
    fenetre.addKeyListener(this);
    //this.add(game);
    //this.add(box);
    affichage.add(this);
    fenetre.pack();
    fenetre.setVisible(true);              
  }

public void start()
  {
    if(gameRunner==null)
      {
	gameRunner = new Thread(this);
	gameRunner.start();
      }
  }

public void stop()
  {
    if(gameRunner.isAlive())
      gameRunner.stop();
    gameRunner=null;
  }
    
public void destroy()
  {
  }
   
public void run()
  {
    gameOver=false;
    while(!gameOver)
      {
	gameOver=game.step();

	repaint();
	try 
		{
			Thread.sleep(200);
		}
	catch (InterruptedException e){}
      }
  }


public void paint(Graphics g)
  {
    game.paint(g,0,0);
    box.setScore(game.score());
    box.paint(g,5,ys-40);
    if(gameOver)
      {
	Font tmp=getFont();
	g.setColor(Color.red);
	g.setFont(new java.awt.Font("TimesRoman",Font.BOLD,18));
	g.drawString("Game Over",10,ys/2);
	g.setFont(tmp);
	g.setColor(Color.black);
	System.out.println("Game Over. Nombre de lignes = " + game.nbLignes); 
      }
  }

public void  keyPressed(KeyEvent e)
    {	
    }

public void  keyReleased(KeyEvent e)
    {
    }

public void  keyTyped(KeyEvent e)
    {
	char key=e.getKeyChar();
	switch (key)
	    {
	    case 'R': game = new TetrisGame(x,y,false); 
		stop();
		start();
		break;
	    }
	
	if(!gameOver)
	    {
		switch (key)
		    {
		    case 'h':
		    case 'H': game.move_left(); repaint(); break;
		    case 'l':
		    case 'L': game.move_right(); repaint(); break;
		    case 'j':
		    case 'J': game.rotate_ccw(); repaint(); break;
		    case 'k':
		    case 'K': game.rotate_cw(); repaint(); break;
		    case ' ': game.drop(); repaint(); break;
		    }
	    } 
  }

public static void main(String[] args)
	{
		Tetris tetris = new Tetris();
	}

public Grid getGrid()
	{
		return game.getGrid();
	}

public TetrisPiece getTetrisPiece()
	{
		return game.getTetrisPiece();
	}
}

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public interface PosPaintable {
    public void paint(Graphics g,int x,int y);
    }

import java.lang.Throwable;

public class CalculIntervalle implements Runnable {

    Tetris monTetrisAMoi;
    int height;
    Grid grille;
    Grid escalier;

    public void setGrid(Grid g) {
	grille = g;
    }

    public void setPiece(Grid p) {
	escalier = p;
    }

    public int getHeight() {
	boolean pouet=false;
	int j = height;

	while ((j>=0)&&(!pouet)) {
	    if (grille.grid[(int)grille.x/2][j]!=0) pouet = true;
	    j--;
	}   

	if (escalier.y==1) return j;
	if (escalier.y==2) return j-1;
	if (escalier.y==3) return j-2;
	
	return 0;
    }
    
    public int getLeft() {
	boolean pouet = false;
	int j=(int)grille.x/2;

	while ((j>0)&&(!pouet)) { 	
	    if (grille.grid[j][/*height*/5]!=0) pouet = true;
	    j--;
	}

	if (escalier.x==2) return j-1;
	if (escalier.x==3) return j;
	
	return 0;
    }
    
    public int getRight() {
	boolean pouet = false;
	int i=(int)grille.x/2;

	while ((i<grille.x)&&(!pouet)) { 
	    if (grille.grid[i][/*height*/5]!=0) pouet = true;
	    i++;
	}

	if (escalier.x==2) return i+1;
	if (escalier.x==3) return i;
	return 0;
    }

    public CalculIntervalle (Tetris T) {
		monTetrisAMoi = T;
		height = T.game.playfield.sizey();
    }


    public void run () {
	for (;;) {
	    try {
		Thread.sleep(300);
		if (monTetrisAMoi.game.bougee) {
		    height--;
		    monTetrisAMoi.game.initBougee();
		}
	    }
	    catch (InterruptedException e) {
		System.out.println("Erreur Stratege.nouvellePiece iexc : " + e);
	    }
	}
	
    }
    
}

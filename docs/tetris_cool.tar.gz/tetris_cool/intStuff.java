class intAnd implements intOp {
public int op(int a,int b) {return a & b;}
}
interface intComp {
public boolean comp(int a,int b);
}
class intEq implements intComp {
public boolean comp(int a, int b) {return a==b;}
}
class intFirst implements intOp {
public int op(int a,int b) {return a; }
}
class intGt implements intComp {
public boolean comp(int a, int b) {return a>b;}
}
class intGtEq implements intComp {
public boolean comp(int a, int b) {return a>=b;}
}
class intLt implements intComp {
public boolean comp(int a, int b) {return a<b;}
}
class intLtEq implements intComp {
public boolean comp(int a, int b) {return a<=b;}
}
class intNonZero implements intComp {
public boolean comp(int a, int b) {return (a!=0) && (b!=0);} 
}
interface intOp {
public int op(int a,int b);
} 
class intOr implements intOp {
public int op(int a,int b) {return (a | b);}
}
class intSecond implements intOp {
public int op(int a,int b) {return b; }
}
class intXor implements intOp {
public int op(int a,int b) {return a ^ b;}
}

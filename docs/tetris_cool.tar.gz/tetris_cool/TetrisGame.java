import java.lang.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class TetrisGame extends JPanel implements PosPaintable {
    Grid playfield;
    TetrisPiece piece;
    int curScore;
    int nbLignes;
    int px,py; 
    intNonZero testNonZero;
    intOr      putDown;
    boolean tombee;
    boolean bougee;
    
    public TetrisGame(int xs,int ys,boolean randomCrap)
    {
	playfield=new Grid(xs,ys,1);
	clear();
	piece = new TetrisPiece();
	py=0;
	px=(xs-piece.sizex())/2;
	testNonZero = new intNonZero();
	putDown = new intOr();
	curScore=0;
	nbLignes = 0;
	tombee = false;
	bougee = false;
    }
    
    public void initTombee() {
	tombee = false;
    }
    public void initBougee() {
	bougee = false;
    }
    
    
    public void clear() {
	playfield.fill(0,0,playfield.sizex(),playfield.sizey(),0);
    }
    
    public void paint(Graphics g, int x,int y)
    {
	
	this.setPreferredSize(new Dimension(400,600)); 
	g.setColor(Color.white);
	g.fillRect(2,2,playfield.sizex()*10+1,playfield.sizey()*10+1);
	g.setColor(Color.black);
       
	g.drawRect(x,y,2+playfield.sizex()*10,2+playfield.sizey()*10);
	for(int j=0;j<playfield.sizey();j++) {
	    for(int i=0;i<playfield.sizex();i++) {
		
		if(playfield.grid[i][j]!=0) {
		    g.setColor(playfield.get_Color(i,j));
		    g.fill3DRect(3+x+i*10,3+y+j*10,8,8,false);
		}
		
		else if ((i>=px) && (i<px+piece.sizex()) && (j>=py) && (j<py+piece.sizey()) && (piece.grid[i-px][j-py]!=0)) {
		    g.setColor(piece.get_Color(i-px,j-py));   
		    g.fill3DRect(3+x+i*10,3+y+j*10,8,8,true); 
		}
	    }
	}
	g.setColor(Color.black);	
    }
    
    
    public boolean step() {
	if (playfield.compare(piece,px,py+1,testNonZero)) {
	    // Put down the piece
	    playfield.put_on(piece,px,py,putDown);
	    tombee = true;
	    // Clear out full lines
	    for(int j=playfield.sizey()-1;j>=0;j--)
		while(testFullLine(j)==true) {
		    deleteLine(j);
		    // Simple scoring function
		    curScore+=10;
		    nbLignes++;
		    System.out.println("J'ai fait une ligne !! Nombre de lignes = " +nbLignes);
		}
	    
	    // Put on a new piece
	    piece = new TetrisPiece();
	    py=0;
	    px=(playfield.sizex()-piece.sizex())/2;
	    if (playfield.compare(piece,px,py,testNonZero)) {
		//tombee = true;
		return true;
	    }
	    
	}
	py++;
	bougee = true;	
	return false;
    }
    
    private boolean testFullLine(int y) {
	for (int i=0;i<playfield.sizex();i++) {
	    if (playfield.grid[i][y]==0) return false;
	}
	return true;
    }
    
    private void deleteLine(int y) {
	for(int j=y;j>0;j--) {
	    for (int i=0;i<playfield.sizex();i++) playfield.grid[i][j]=playfield.grid[i][j-1];
	    for (int i=0;i<playfield.sizex();i++) playfield.grid[i][0]=0;
	}
    }
    
    // Data-returning methods
    
    public int score() {
	return curScore;
    }
    
    // Game-play interface methods
    
    public void move_left(int i) {
	if (playfield.compare(piece,px-i,py,testNonZero)) return;
	px-=i;
    }

    public void move_left() {
	move_left(1);
    }
    
    public void move_right(int i) {
	if (playfield.compare(piece,px+i,py,testNonZero)) return;
	px+=i;
    }
    
    public void move_right() {
	move_right(1);
    }
    
    public void rotate_cw() {
	TetrisPiece test=new TetrisPiece(piece);
	test.rotate_cw();
	if (!playfield.compare(test,px,py,testNonZero)) piece=test;
    }
    
    public void rotate_ccw() {
	TetrisPiece test=new TetrisPiece(piece);
	test.rotate_ccw();
	if (!playfield.compare(test,px,py,testNonZero)) piece=test;
    }
    
    public void drop() {
	while (!playfield.compare(piece,px,py+1,testNonZero)) py++;
    }
    
    public Grid getGrid() {
	return playfield;
    }
    
    public TetrisPiece getTetrisPiece() {
	return piece;
    }
    
}

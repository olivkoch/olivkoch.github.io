public class Effecteur
{
    Tetris monTetris; // pour pouvoir agir sur le jeu
    
    public void effectue(Position p)
    {
	int X = monTetris.game.piece.x; // Initialisation de l'abscisse de la pi�ce
	
	for (int i=0;i<p.theta;i++) monTetris.game.piece.rotate_cw(); // rotation
	
	
	if (p.x>((monTetris.game.playfield.x-X)/2)) { // d�placement � droite
	    for (int j=0;j<p.x-((monTetris.game.playfield.x-X)/2);j++) monTetris.game.move_right();
	}
	
	if (p.x<((monTetris.game.playfield.x-X)/2)) { // d�placement � gauche
	    for (int j=0;j<((monTetris.game.playfield.x-X)/2)-p.x;j++) monTetris.game.move_left();
	}
	
	monTetris.game.drop(); // descente finale de la pi�ce
    }
    
    public Effecteur (Tetris T)  // Constructeur
    {
	monTetris = T;
    }
   
}

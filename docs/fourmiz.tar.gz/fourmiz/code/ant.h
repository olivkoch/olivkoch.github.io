#ifndef _Ant_
#define _Ant_

#include <stdlib.h>
#include <iostream.h>
#include <assert.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include <stdio.h>
#include "init.h"

class Ant {

  friend class Nest;
  friend class Walk;

 public:
  Ant();
  ~Ant();
  int Ant::sign(int r);
  int Ant::max2(int a, int b);
  int Ant::max3 (int a, int b, int c);
  int Ant::get_map(int x, int y, int *map, int length);
  int* Ant::think(int *floor, int *count_floor);

 private:
  struct timeval *tv;
  struct timezone *tz;
  int id;
  int state;
  int age;
  int miles;
  int hand;
  int x,y, nx, ny;
  int xborn, yborn;
  int hunger;
  int field[9];
  int timeofday;

};

#endif

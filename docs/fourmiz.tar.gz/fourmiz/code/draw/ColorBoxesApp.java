import java.awt.*;
public class ColorBoxesApp extends Frame {
    public ColorBoxesApp() {
	setSize(400,200);
	setVisible(true);
    }
    public static void main(String args[]) {
	Frame fr = new ColorBoxesApp (); }
    public void paint(Graphics g) {
	int rval, gval, bval;
	for (int j = 30; j<(this.getSize().height-25); j+=30)
	    for (int i=5;i < (this.getSize().width-25); i+=30)
		{
		    rval = (int)Math.floor(Math.random()*256);
		    gval = (int)Math.floor(Math.random()*256);
		    bval = (int)Math.floor(Math.random()*256);
		    g.setColor(new Color(rval, gval, bval));
		    g.fillRect(i,j,25,25);
		}
    }
}

#include <stdlib.h>
#include <iostream.h>
#include <assert.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include <stdio.h>
#include "walk.h"
#include "ant.h"

int main() {

  Walk hill;
  hill.estherize();
  hill.asleep();
  hill.activate();
  hill.asleep();
  hill.restart();
  hill.decimate();
  hill.dump_map();
  hill.dump_pop();
  hill.evaporate();
  hill.create();
  hill.feed();
  hill.think(); // analyses and decide
  hill.move();
  hill.update();

  cout << "Salut !!! \n";
  return 0;
}

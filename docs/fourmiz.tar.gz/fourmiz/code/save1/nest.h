#ifndef _Nest_
#define _Nest_

#include "ant.h"

class Nest {

  public :
    Nest(int *map);
  ~Nest();
  int Nest::sign(int r);
  void Nest::test();
  void Nest::activate();
  void Nest::asleep();
  void Nest::restart();
  void Nest::dump_pop();
  void Nest::decimate();
  void Nest::kill(int i);
  void Nest::create();
  void Nest::feed();
  void Nest::update();
  void Nest::move();
  void Nest::look(int *map);
  void Nest::think(int *map);
  
  private :
    int xn, yn;
  int stock;
  int population;
  Ant *ants;
  struct timeval *tv;
  struct timezone *tz;
  int timeofday;
  FILE *mapf, *antsf;

  friend class Walk;
};

#endif

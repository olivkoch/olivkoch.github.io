#ifndef _Walk_
#define _Walk_

#include "nest.h"

class Walk {

  public:
  Walk();
  ~Walk(void);
  void Walk::init_map();
  void Walk::dump_map();
  void Walk::dump_pop();
  void Walk::evaporate();
  void Walk::activate();
  void Walk::asleep();
  void Walk::restart();
  void Walk::decimate();
  void Walk::estherize();
  void Walk::create();
  void Walk::feed();
  void Walk::update();
  void Walk::think();
  void Walk::move();

 private:
  FILE *map_initf;
  FILE *antsf, *statf, *mapf;
  int *map;
  Nest *nests;

  friend class Nest;

};

#endif

#include "ant.h"

Ant::Ant() {
  miles = 0;  // initializing ant
  age = 0;
  hunger = 0;
  //tv = new struct timeval;
  //tz = new struct timezone;
  //timeofday = gettimeofday(tv,tz);
  //srand(getpid()*(tv->tv_usec));
  state = 0;
  hand = (rand()%2-1)*2+1;
  for (int k=0;k<9;k++) field[k]=0;
  return;
}

Ant::~Ant() {
  //delete tv,tz;  // killing ant
  return;
}

int Ant::sign (int r) {
 if (r > 0) return 1;
  else if (r < 0) return -1;
  else return 0;
}

void Ant::affiche() {
  cout << "Type : " << state << "\n";
  cout << "Hand : " << hand << "\n";
  cout << "Xborn: " << xborn << "\n";
  cout << "Yborn: " << yborn << "\n";

}

void Ant::die() {
  cout << "ant dying\n";
  delete this;
  return;
}

int Ant::get_map(int x, int y, int *map) {

  if ((x>=size_x)||(y>=size_y)) return 1;
  if ((x<0)||(y<0)) return 1;
  return (map[x*size_x+size_y]);
 
}

int* Ant::think(int *map) {
  //the big one
  int *r;
  r = new int[2];

  if (state == 2) {
    // ant going back home / food
    int xb, yb, dx, dy, floor;
    xb = x+sign(xborn-x);
    yb = y+sign(yborn-y);
    floor = get_map(xb,yb, map);

    while ( (get_map(xb,yb,map))%3 != 0)
      {
	dx = xb-x;
	dy = yb-y;
	xb = x+sign(dx+hand*dy);
	yb = y+sign(dy-hand*dx);
      }
      }
  r[0]=23;
  r[1]=12;
  return r;
  
}

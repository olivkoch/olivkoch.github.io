// definition of constant parameters

const int size_x = 320;       // size of window <unit : pixels>
const int size_y = 240;       // size of window <unit : pixels>
const int exp_of_life = 100;  // ants expect of life
const int colony=90;          // number of ants at start
const int hunger_limit=10;    // time limit before starve death
const int miles_limit=1000;   // miles limit before death
const int price_of_life=5;    // food payed for each ant created
const int pop_limit=400;    // max number of ants per nest
const int num_nests=4;     // number of nets
const int prob_left=2;        // left handed tendency (out of 10)
const int prob_right=8;       // right handed tendency (out of 10)
const int tactivate=10;       // time delay between two 'awaking ants'
const int tdump=10;           // time delay between two map dumps

// important :
// colony < pop_limit !!!

#ifndef _Ant_
#define _Ant_

#include <stdlib.h>
#include <iostream.h>
#include <assert.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include <stdio.h>
#include "init.h"

class Ant {

  friend class Nest;
  friend class Walk;

 public:
  Ant();
  ~Ant();
  int Ant::sign(int r);
  void Ant::affiche ();
  void Ant::die();
  int Ant::get_map(int, int, int*);
  int* Ant::think(int *map);

 private:
  struct timeval *tv;
  struct timezone *tz;
  int state;
  int age;
  int miles;
  int hand;
  int x,y, nx, ny;
  int xborn, yborn;
  int hunger;
  int field[9];
  int timeofday;

};

#endif

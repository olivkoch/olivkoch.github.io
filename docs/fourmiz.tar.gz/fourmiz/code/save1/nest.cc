#include "nest.h"

int Nest::sign(int r) {
  if (r > 0) return 1;
  else if (r < 0) return -1;
  else return 0;
}

Nest::Nest(int *map) {

  cout << "creating Nest\n";
  population = colony;
  tv = new struct timeval;
  tz = new struct timezone;
  timeofday = gettimeofday(tv,tz);
  srand(getpid()*(tv->tv_usec));
  xn = rand()%size_x;
  yn = rand()%size_y;               // randomize nest position
  while ( map[xn*size_y+yn] > 0 ) { // but : no nest on wall or food
    xn = rand()%size_x;
    yn = rand()%size_y; }
  ants=new Ant[pop_limit];          // creates nest population
  for (int i=0;i<colony;i++)        // initializes ants birth place
    {
      ants[i].xborn=xn; ants[i].yborn=yn; ants[i].x=xn; ants[i].y=yn; 
      ants[i].nx=xn+(rand()%2-1)*2+1; 
      ants[i].ny=yn+(rand()%2-1)*2+1; 
    }
  return;
}

Nest::~Nest() {

  cout << "killing nest\n";
  delete[] ants;
  return;
}

void Nest::activate() {
  
  for (int i=0;i<population;i++)
    {
      if (ants[i].state == 3) 
	{                     // wakes up 1 sleeping ant out of 10
	  timeofday = gettimeofday(tv,tz);
	  srand(getpid()*(tv->tv_usec));
	  if (rand()%2 == 0) ants[i].state = 0; 
	}
    }
  return;
}

void Nest::asleep() {
for (int i=0;i<population;i++)
    {
      if (ants[i].state != 3) 
	{                 // asleeps 1 sleeping ant out of 10
	  timeofday = gettimeofday(tv,tz);
	  srand(getpid()*(tv->tv_usec));
	  if (rand()%2 == 0) ants[i].state = 3;
	}
    }
 return;
}

void Nest::restart() {
 for (int i=0;i<population;i++)
    {
      if ( (ants[i].state == 2)&&(ants[i].x = xn)&&(ants[i].y = yn) )
	{
	  ants[i].state = 0;
	  stock++;
	}
    }
 return;
}

void Nest::dump_pop() {
if ( (antsf = fopen("./files/ants","a+")) == NULL )  // opening file ants
    cout <<  "**ERROR : opening ./files/ants\n";    
for (int i=0;i<population;i++)
    {
      fprintf (antsf, "%d %d %d\n",ants[i].state, ants[i].x, ants[i].y);
    }
 fclose(antsf);
 return;
}

void Nest::kill(int i) {

  cout << "killing ant\n";
  if (i < pop_limit-1)
  for (int j=i;j<pop_limit-1;j++) ants[j]=ants[j+1];
  population--;
  
}

void Nest::decimate() {
  for (int i=0;i<population;i++)
    {
      if (ants[i].age > exp_of_life) kill(i); // too old ants die
      timeofday = gettimeofday(tv,tz);
      srand(getpid()*(tv->tv_usec));
      if (rand()%1000 == 0) kill(i); // chance kills 1 ant out of 1000
      if (ants[i].hunger > hunger_limit) kill(i); // too hungry ants die
      if (ants[i].miles > miles_limit) kill(i); // too tired ants die

    }
}

void Nest::create() {
  while (stock > 5) {
    if (population < pop_limit) {   // creation allowed
    population++;
    stock = stock-5;
    cout << "ant born in Nest " << xn << " " << yn << "\n";
    ants[population].miles = 0;  // initializing ant
    ants[population].age = 0;
    ants[population].hunger = 0;
    tv = new struct timeval;
    tz = new struct timezone;
    timeofday = gettimeofday(tv,tz);
    srand(getpid()*(tv->tv_usec));
    ants[population].state = 0;
    ants[population].hand = rand()%2;
    ants[population].field[0]=0; ants[population].field[1]=0; ants[population].field[2]=0;
    }
  }
  return;
}

void Nest::feed() {
 for (int i=0;i<population;i++)
    {
      if ( (ants[i].hunger > hunger_limit*2/3 )&&(ants[i].state == 2) )
	{ // here : ant is hungry and avoid death by eating the food she was bringing back home
	  ants[i].hunger = 0;
	  ants[i].state = 0;
	}
    }
 return;
}

void Nest::update() {
for (int i=0;i<population;i++)
    {
      ants[i].age++;
      ants[i].hunger++;
      if ( ants[i].state <=2 ) ants[i].miles++;
    }
 return;
}

void Nest::move() {
  int dx, dy;
for (int i=0;i<population;i++)
  {
    dx = ants[i].nx-ants[i].x;
    dy = ants[i].ny-ants[i].y;
    ants[i].x = ants[i].nx;
    ants[i].y = ants[i].ny;
    ants[i].nx = ants[i].x+dx;
    ants[i].ny = ants[i].y+dy;
  }
 return;
}

void Nest::look(int *map) {
  int dx, dy;
  int i,j; 
  for (int k=0;k<population;k++)
    {
      // ants looking at its neighbourhood (updating field)
      //cout << "\nANT : " << " " << ants[k].x << " " << ants[k].y << endl;
      //cout << "DEV : " << " " << ants[k].nx << " " << ants[k].ny << endl;
      dx = ants[k].nx-ants[k].x;
      dy = ants[k].ny-ants[k].y;
      ants[k].field[3]=ants[k].nx;
      ants[k].field[4]=ants[k].ny;
      ants[k].field[5]=map[size_y*ants[k].nx+ants[k].ny]; // looking straight forward
      i = ants[k].x+sign(dx+dy);
      j = ants[k].y+sign(dy-dx);
      //cout << "DRO : " << " " << i << " " << j << endl;
      ants[k].field[6]=i;
      ants[k].field[7]=j;
      ants[k].field[8]=map[size_y*i+j]; // looking on the right insight
      i = ants[k].x+sign(dx-dy);
      j = ants[k].y+sign(dx+dy);
      //cout << "GAU : " << " " << i << " " << j << endl; 
      ants[k].field[0]=i;
      ants[k].field[1]=j;
      ants[k].field[2]=map[size_y*i+j]; // looking on the left insight 

    }
  return;
  
}

void Nest::think(int *map) {

  int *r;
  r = new int[2];
  for (int i=0;i<population;i++)
  {
    // for each ant : thinking where to go according to the field
    r = ants[i].think(map);
    ants[i].nx = r[0];
    ants[i].ny = r[1];
  }
  return;
}



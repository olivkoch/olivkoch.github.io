#include "walk.h"

Walk::Walk() {
  cout << "\n***  Initializing life...  ***\n";
  init_map();
  nests = new Nest[num_nests](map);
  return;
}

Walk::~Walk(void) {
  cout << "***  Killing life...  ***\n";
  delete[] map;
  delete[] nests;
}

void Walk::init_map() {
  map = new int [size_x*size_y];
  for (int i=0;i<size_x;i++)
	    for (int j=0;j<size_y;j++) map[i*size_y+j]=0;
  if ( (map_initf = fopen("./files/init_map","r")) == NULL ) //opening init_map file
    cout << "**ERROR : No init map ! Please create.\n";
  else {
    cout << "Reading init_map\n";                            // reading init_map
    char* object;
    object = new char[25];
    while ( fgets(object,25,map_initf) != NULL )             // for each line of the file
      {
	int type, floortype, xc, yc, rc, xb1, xb2, yb1, yb2;
	if (object[0]=='1') 
	  {                                                  // here : the object is a circle
	    sscanf(object,"%d %d %d %d %d",&type,&floortype, &xc, &yc, &rc);
	    for (int i=xc-rc-1;i<xc+rc+1;i++) 
	      for (int j=yc-rc-1;j<yc+rc+1;j++)
		if ( ((i-xc)*(i-xc)+(j-yc)*(j-yc)) <= rc*rc ) map[i*size_y+j]=floortype;
	  }
	else if (object[0]=='0') {                           // here : the object is a box
	  sscanf(object,"%d %d %d %d %d %d",&type,&floortype, &xb1, &yb1, &xb2, &yb2);
	  for (int i=xb1-1;i<xb2;i++) 
	    for (int j=yb1-1;j<yb2;j++) map[i*size_y+j]=floortype;
	}
      }
  }
  return;
}

void Walk::dump_map() {
  if ( (mapf = fopen("./files/map","w+")) == NULL )           // opening map file
    cout << "**ERROR : opening ./files/map\n";
  else {
    for (int i=0;i<size_x;i++)
      for (int j=0;j<size_y;j++)                              // writing in map file
	if (map[i*size_y+j] > 0) fprintf (mapf, "%d %d %d\n",map[i*size_y+j],i,j);
  }
 
}

void Walk::dump_pop() {
  cout << "dumping pop\n";
  if ( (antsf = fopen("./files/ants","w")) == NULL )  // creating new file ants
    cout <<  "**ERROR : creating ./files/ants\n";    
  fclose(antsf);
  for (int i=0;i<num_nests;i++)
    nests[i].dump_pop();
  return;
}

void Walk::evaporate() {
    cout << "evaporating esther !\n";
    for (int i=0;i<size_x;i++)
      for (int j=0;j<size_y;j++)
	if (map [i*size_y+j] > 5) map [i*size_y+j]--;
  return;
}

void Walk::activate() {
  cout << "activating sleeping ants\n";
  for (int i=0;i<num_nests;i++)
    nests[i].activate();
  return;
}

void Walk::asleep() {
cout << "asleeping ants\n";
  for (int i=0;i<num_nests;i++)
    nests[i].asleep();
  return;
}

void Walk::restart() {
  cout << "restarting ants in nests\n";
  for (int i=0;i<num_nests;i++)
    nests[i].restart();
  return;
}

void Walk::decimate() {
cout << "decimating ants\n";
  for (int i=0;i<num_nests;i++)
    nests[i].decimate();
  return;
}

void Walk::estherize() {
 cout << "estherizing floor\n";
  for (int i=0;i<num_nests;i++)
    {
      for (int j=0;j<nests[i].population;j++)
	if (nests[i].ants[j].state == 2) map[size_y*nests[i].ants[j].x+nests[i].ants[j].y]++;
    }
  return;
}

void Walk::create() {

  cout << "creating new ants\n";
  for (int i=0;i<num_nests;i++)
    nests[i].create();
  return;
}

void Walk::feed() {
cout << "feeding ants\n";
  for (int i=0;i<num_nests;i++)
    nests[i].feed();
  return;
}

void Walk::update() {
cout << "updating ants\n";
  for (int i=0;i<num_nests;i++)
    nests[i].update();
  return;
}

void Walk::move() {
cout << "moving ants\n";
  for (int i=0;i<num_nests;i++)
    nests[i].move();
  return;
}

void Walk::think() {
cout << "ants thinking\n";
  for (int i=0;i<num_nests;i++)
    {
      nests[i].look(map);
      nests[i].think(map);
      return;
    }
}

#include "ant.h"

Ant::Ant() {
  id=0;
  miles = 0;  // initializing ant
  age = 0;
  hunger = 0;
  //tv = new struct timeval;
  //tz = new struct timezone;
  //timeofday = gettimeofday(tv,tz);
  //srand(getpid()*(tv->tv_usec));
  state = 0;
  hand = (rand()%2-1)*2+1;
  for (int k=0;k<9;k++) field[k]=0;
  return;
}

Ant::~Ant() {
  //delete tv,tz;  // killing ant
  return;
}

int Ant::sign (int r) {
 if (r > 0) return 1;
  else if (r < 0) return -1;
  else return 0;
}

int Ant::max2(int a, int b) {
  if (a<b) return a; else return b;
}

int Ant::max3(int a, int b, int c) {

  return (max2(max2(a,b),c));
}

int Ant::get_map(int x, int y, int *map, int length) {

  for (int m=0;m<length;m++) 
    {
      if (map[3*m] != x) continue;
      if (map[3*m+1] == y) return map[3*m+2];
    }  
  return 0;
}

int* Ant::think(int *floor, int *count_floor) {
  
  int *r;
  r = new int[3];
  r[2] = 0;
  int xb, yb, dx, dy, hfloor;
  
  //checking fields
  if (debug==1) printf ("POSITION %d %d  DIRECTION %d %d  STATUS %d\n",x,y,nx,ny,state);
  if (debug==1) printf ("FIELD %d %d %d || %d %d %d || %d %d %d\n",field[0],field[1],field[2],field[3],field[4],field[5],field[6],field[7],field[8]);
  
  if (state == 3)
    { // ant sleeping : don't move
      if (debug==1) printf("Ant asleep don't move\n");
      r[0] = x; r[1] = y; return r;
    }
  
  if (state == 2) {
    // ant going back home with food
    // here : ant is at home; she leaves food and seeks again
    if ((x==xborn)&&(y==yborn)) 
      {
	printf("\nFOOD IN THE FRIDGE\n");
	state=0;
	r[2]=3;
	r[0]=x+sign(x-nx);
	r[1]=y+sign(y-ny);
	return r;
      }
   
    // here : ant isn't at home yet; 
    xb = x+sign(xborn-x);
    yb = y+sign(yborn-y);
    hfloor = get_map(xb,yb, floor, count_floor[0]);
    
    int countr=0;
    while ( ((get_map(xb,yb,floor, count_floor[0]) ==1)||(get_map(xb,yb,floor, count_floor[0]) ==2))&&(countr<5))
      {
	dx = xb-x;
	dy = yb-y;
	xb = x+sign(dx+hand*dy);
	yb = y+sign(dy-hand*dx);
	countr++;
      }
    if (countr<5) {
    r[0] = xb; r[1] = yb;
    if (debug==1) printf("0 : Ant 2 thought : here %d %d   go to %d %d\n",x,y,xb,yb);
    r[2]=1; // ground has to be estherized
    return r;
    }
    else
      { // here : ant stuck - go back
	r[0]=x+sign(x-nx);
	r[1]=y+sign(y-ny);
	if (debug==1) printf("3 : Ant 2 thought : here %d %d   go to %d %d\n",x,y,xb,yb);
	return r;
      }
  }

  if (state == 0) {
    // ant lost in the garden seeking food
    // first : look for food
    for (int k=2;k<9;k=k+3)
      if (field[k] == 2) { 
	r[0] = field[k-2]; r[1] = field[k-1]; 
	printf("\nFOOD FOUND by %d   NEST X=%d Y=%d\nFIELD %d %d %d || %d %d %d || %d %d %d\n0 : Ant 0 thought : here %d %d   go to %d %d\n",id,xborn,yborn,field[0],field[1],field[2],field[3],field[4],field[5],field[6],field[7],field[8],x,y,r[0],r[1]);
	state=2; 
	r[2]=2; // food found has to be deleted
	return r;
      }
    // second : look for maximum esther
    int rb;
    int eb = 0;
    for (int k=2;k<9;k=k+3)
      if (field[k] >= 5) { if (field[k] >= eb) { eb = field[k]; rb = k; }}
    if (eb >= 5) { r[0] = field[rb-2]; r[1] = field[rb-1]; 
    if (debug==1) printf("1 : Ant 0 thought here : %d %d   go to %d %d\n",x,y,r[0],r[1]);
    state=1;
    return r;
    }
    
    // third : else : go anywhere
    int k, di;
    di = rand()%10+1;
    if (di <= prob_left) k=2;
    else 
      if (di >= prob_right) k=8;
      else k=5;
    r[0] = field[k-2]; r[1] = field[k-1];
    int countr=0;
    while ((field[k] != 0)&&(countr<3)) {
      countr++;
      di = rand()%10+1;
      if (di <= prob_left) k=2;
      else 
	if (di >= prob_right) k=8;
	else k=5;
    }
    if (countr<4) {
      r[0] = field[k-2]; r[1] = field[k-1];
      if (debug==1) printf("2 : Ant 0 thought here : %d %d   go to %d %d\n",x,y,r[0],r[1]);
      return r; 
    }
    // else : ant stuck - go back
    else
      {
	r[0]=x+sign(x-nx);
	r[1]=y+sign(y-ny);
	if (debug==1) printf("3 : Ant 0 thought here : %d %d   go to %d %d\n",x,y,r[0],r[1]);
	return r;
      }
  }
  
  if (state == 1) {
    //ant following esthers
    //first : look for food
    for (int k=2;k<9;k=k+3)
      if (field[k] == 2) { 
	r[0] = field[k-2]; r[1] = field[k-1]; 
	state=2;
		printf("\nFOOD FOUND   NEST X=%d Y=%d\n0 : Ant 1 thought : here %d %d   go to %d %d\n",xborn,yborn,x,y,xb,yb);

	r[2]=2; // food found has to be deleted
      return r;}
    
    //second : look for esthers
    int rb;
    int eb = 0;
    for (int k=2;k<9;k=k+3)
      if (field[k] >= 5) { if (field[k] >= eb) { eb = field[k]; rb = k; }}
    if (eb >= 5) { r[0] = field[rb-2]; r[1] = field[rb-1];
    if (debug==1) printf("1 : Ant 1 thought here : %d %d   go to %d %d\n",x,y,r[0],r[1]);
    return r;
    }
    //third : no food, no esthers ? -> go the other way around
    r[0]=x+sign(x-nx);
    r[1]=y+sign(y-ny);
    return r;

  }

  if (debug==1) printf("Didn't think that much...\n");
  return r;
}

#ifndef _Nest_
#define _Nest_

#include "ant.h"

class Nest {

  public :
    Nest(int *floor, int *count_floor);
  ~Nest();
  int Nest::get_map(int x, int y, int *map, int length);
  int Nest::sign(int r);
  void Nest::test();
  void Nest::activate();
  void Nest::asleep();
  void Nest::dump_pop();
  void Nest::decimate();
  void Nest::kill(int i, int code);
  void Nest::create();
  void Nest::feed();
  void Nest::update();
  void Nest::move();
  void Nest::look(int *floor, int *count_floor);
  int* Nest::think(int *floor, int* count_floor);
  
  private :
    int id;
  int xn, yn;
  int stock;
  int population;
  Ant *ants;
  struct timeval *tv;
  struct timezone *tz;
  int timeofday;
  FILE *mapf, *antsf;
  
  friend class Walk;
};

#endif

#include <stdlib.h>
#include <iostream.h>
#include <assert.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include <stdio.h>
#include "walk.h"
#include "ant.h"

int main(int argc, char* argv[]) {

  if (argv[1]==NULL) 
    {
      printf("*************************\nworld <int nbtours>\nnbtours : number of loops\n*************************\n"); 
      return -1;
    }

  if (colony>pop_limit)
    {
printf("Parameters error : 'colony' should be less or equal to 'pop_limit'\nPlease fix that in init.h\n"); 
      return -1;
    }

  printf("Let's go!\n");
  int nbtour = atoi(argv[1]);
  long int tick, tick2;
  Walk hill;
  FILE *timing_file;
  struct timeval *tv = new struct timeval;
  struct timezone *tz = new struct timezone;

  if ( (timing_file = fopen("timing","w+")) == NULL )  // opening timing file
    printf("**ERROR : opening  timing_file\n");

  for (int t=0;t<nbtour;t++) {
    if (debug==1) printf("**************** TOUR %d ****************\n",t);
    else 
      {
	printf("|");
	fflush(stdout);
      }
    gettimeofday(tv,tz);
    tick=tv->tv_usec;
    hill.update();
    gettimeofday(tv,tz);
    tick2=tv->tv_usec;
    fprintf(timing_file,"update : \t%ld\n",tick2-tick);
    tick=tick2;
    hill.think();
    gettimeofday(tv,tz);
    tick2=tv->tv_usec;
    fprintf(timing_file,"think : \t%ld\n",tick2-tick);
    tick=tick2;
    hill.move();
    gettimeofday(tv,tz);
    tick2=tv->tv_usec;
    fprintf(timing_file,"move  : \t%ld\n",tick2-tick);
    tick=tick2;
    hill.decimate();
    gettimeofday(tv,tz);
    tick2=tv->tv_usec;
    fprintf(timing_file,"decimate : \t%ld\n",tick2-tick);
    tick=tick2;
    hill.create();
    gettimeofday(tv,tz);
    tick2=tv->tv_usec;
    fprintf(timing_file,"create : \t%ld\n",tick2-tick);
    tick=tick2;
    hill.asleep(t);
    gettimeofday(tv,tz);
    tick2=tv->tv_usec;
    fprintf(timing_file,"asleep : \t%ld\n",tick2-tick);
    tick=tick2;
    hill.activate(t);
gettimeofday(tv,tz);
    tick2=tv->tv_usec;
    fprintf(timing_file,"activate : \t%ld\n",tick2-tick);
    tick=tick2;
    hill.evaporate(t);
gettimeofday(tv,tz);
    tick2=tv->tv_usec;
    fprintf(timing_file,"evaporate : \t%ld\n",tick2-tick);
    tick=tick2;
    hill.feed();
gettimeofday(tv,tz);
    tick2=tv->tv_usec;
    fprintf(timing_file,"feed    : \t%ld\n",tick2-tick);
    tick=tick2;
    hill.dump_map();
gettimeofday(tv,tz);
    tick2=tv->tv_usec;
    fprintf(timing_file,"dump map : \t%ld\n",tick2-tick);
    tick=tick2;
    hill.dump_pop();
gettimeofday(tv,tz);
    tick2=tv->tv_usec;
    fprintf(timing_file,"dump pop : \t%ld\n",tick2-tick);
    tick=tick2;
        fprintf(timing_file,"********************************\n");
  }
  
  cout << "\n************* END ********************\n";
  return 0;
}


// TODO : ajout de nouvelle nourriture au hasard !!!
//        + a la sortie du nid, fourmi look for esthers !!!


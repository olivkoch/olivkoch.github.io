#include "walk.h"

Walk::Walk() {
  cout << "\n***  Initializing life...  ***\n";
  init_map();
  result = new int[3*pop_limit];
  nests = new Nest[num_nests](floor, &count_floor[0]);
  for (int k=0;k<num_nests;k++) nests[k].id = k;
  return;
}

Walk::~Walk(void) {
  int pop_total=0;
  for (int i=0;i<num_nests;i++)
    pop_total=pop_total+nests[i].population;
  printf("Population Begin : %d\n",num_nests*colony);
  printf("Population   End : %d\n",pop_total);
  printf("Food : %d          Esthers : %d\n",count_floor[2],count_floor[3]);
  delete[] floor;
  delete[] nests;
}

void Walk::init_map() {
  
  // initialize floor and count_floor
  floor =  new int [3*size_x*size_y];
  for (int m=0;m<4;m++) count_floor[m]=0;
  for (int m=0;m<3*size_x*size_y;m++) { floor[m]=0;}

  //opening init_map file
  if ( (map_initf = fopen("./files/init_map","r")) == NULL ) 
    cout << "**ERROR : No init map ! Please create.\n";
  else {
    //cout << "Reading init_map\n";                            // reading init_map
    char* object;
    int c = 0;
    object = new char[25];
    while ( fgets(object,25,map_initf) != NULL )             // for each line of the file
      {
	int feature_type, floortype, xc, yc, rc, xb1, xb2, yb1, yb2;
	if (object[0]=='1') 
	  {                                                  // here : the object is a circle
	    sscanf(object,"%d %d %d %d %d",&feature_type,&floortype, &xc, &yc, &rc);
	    for (int i=xc-rc-1;i<xc+rc+1;i++) 
	      for (int j=yc-rc-1;j<yc+rc+1;j++)
		if ( ((i-xc)*(i-xc)+(j-yc)*(j-yc)) <= rc*rc ) 
		  { 
		  c = 3*(count_floor[1]+count_floor[2]);
		  floor[c] = i; floor[c+1] = j; floor [c+2] = floortype;
		  count_floor[floortype]++; 
	  }
      }
    
    
	else if (object[0]=='0') {                           // here : the object is a box
	  sscanf(object,"%d %d %d %d %d %d",&feature_type, &floortype, &xb1, &yb1, &xb2, &yb2);
	  for (int i=xb1;i<=xb2;i++) 
	    for (int j=yb1;j<=yb2;j++) 
	      {
		c = 3*(count_floor[1]+count_floor[2]);
		floor[c] = i; floor[c+1] = j; floor [c+2] = floortype;
		count_floor[floortype]++; 
	      }
	}

      }

    // creating wall around the garden so that ants cannot leave the place
    c = 3*(count_floor[1]+count_floor[2]);
    for (int i=0;i<size_x;i++) {floor[c] = i; floor[c+1]=0; floor[c+2]=1; count_floor[1]++; c=c+3;}
    for (int i=0;i<size_x;i++) {floor[c] = i; floor[c+1]=size_y; floor[c+2]=1; count_floor[1]++; c=c+3;}
    for (int j=0;j<size_y;j++) {floor[c] = 0; floor[c+1]=j; floor[c+2]=1; count_floor[1]++; c=c+3;}
    for (int j=0;j<size_x;j++) {floor[c] = size_x; floor[c+1]=j; floor[c+2]=1; count_floor[1]++; c=c+3;}
    
    //updating fllor length -> necessary for creatinf nests
    count_floor[0]=count_floor[1]+count_floor[2]+count_floor[3];
  
    
  }
  return;
}

void Walk::dump_map() {
  if ( (mapf = fopen("./files/map","w+")) == NULL )           // opening map file
    cout << "**ERROR : opening ./files/map\n";
  else { //writing in map file
    for (int i=0;i<3*(count_floor[0]);i=i+3) fprintf (mapf, "%d;%d %d\n", floor[i+2],floor[i],floor[i+1]);
    
  }
 
}

void Walk::dump_pop() {
  //cout << "dumping pop\n";
  if ( (antsf = fopen("./files/ants","w")) == NULL )  // creating new file ants
    cout <<  "**ERROR : creating ./files/ants\n";    
  fclose(antsf);
  for (int i=0;i<num_nests;i++)
    nests[i].dump_pop();
  return;
}

void Walk::evaporate(int t) {
   if ((t%tactivate)==0)
     {
       if (count_floor[3] > 0) 
	 for (int i=0;i<count_floor[0];i++) 
	   if(floor[3*i+2]>5) {
	     if (floor[3*i+2]==5)
	       {
		 // here : esther must be deleted
		 for (int m=3*i;m<count_floor[0];m++) floor[m]=floor[m+3];
		 count_floor[3]--;
	       } 
	     else floor[3*i+2]--;
	   }
     }
   return;
}

void Walk::activate(int t) {
  if ((t%tactivate)==0)
    {
      for (int i=0;i<num_nests;i++)
	nests[i].activate();
    }
  return;
}

void Walk::asleep(int t) {
  if ((t%tactivate)==0)
    {
      for (int i=0;i<num_nests;i++)
	nests[i].asleep();
    }
  return;
}


void Walk::decimate() {
//cout << "decimating ants\n";
  for (int i=0;i<num_nests;i++)
    nests[i].decimate();
  return;
}

void Walk::process(int *result) {

  int len=result[0];
  int right_l;

  for (int k=0;k<len;k++)
    {
      int x=result[3*k+1]; int y=result[3*k+2];
      if (result[3*k+3]==1)
	{
	  // here : adding esther
	  
	  for (int l=0;l<count_floor[0];l++)
	      {
		if ((floor[3*l] == x)&&(floor[3*l+1]==y)) 
		  {
		    if ((floor[3*l+2]<100)&&(floor[3*l+2]>5)) 
		      {
			floor[3*l+2]++; 
			count_floor[3]++;
			return;
		      }
		  }
	      }
	  count_floor[3]++;
	}
      if (result[3*k+3]==2)
	{
	  // here : deleting food
	  for (int l=0;l<count_floor[0];l++)
	      {
		if ((floor[3*l] == x)&&(floor[3*l+1]==y)) 
		  {
		    right_l = l;
		    continue;
		  }
		// here : we found l corresponding to the food to be deleted
	      }
	  for (int m=right_l;m<count_floor[0]-3;m++)
	    {
	      floor[m]=floor[m+3];
	    }
	  count_floor[2]--;
	}
    }
  return;
}

void Walk::create() {

  //cout << "creating new ants\n";
  for (int i=0;i<num_nests;i++)
    nests[i].create();
  return;
}

void Walk::feed() {
  //cout << "feeding ants\n";
  for (int i=0;i<num_nests;i++)
    nests[i].feed();
  return;
}

void Walk::update() {
  
  int pop_total=0;
  count_floor[0]=count_floor[1]+count_floor[2]+count_floor[3];
  //cout << "updating ants\n";
  for (int i=0;i<num_nests;i++)
    {
    nests[i].update();
    pop_total = pop_total+nests[i].population;
    }
  // printing floor infos
    if (debug==1) printf("Length : %d  Wall : %d  Food : %d  Esthers : %d\n",count_floor[0],count_floor[1],count_floor[2],count_floor[3]);
    // finishing simulation when no more ants
    if (pop_total==0) 
      {
	printf("Civilisation disparue. Fin de la simulation\n");
	exit(EXIT_SUCCESS);
      }
      return;
}

void Walk::move() {
  //cout << "moving ants\n";
  for (int i=0;i<num_nests;i++)
    nests[i].move();
  return;
}

void Walk::think() {
  //cout << "ants thinking\n";

  for (int i=0;i<num_nests;i++)
    {
      nests[i].look(floor, &count_floor[0]);
      result = nests[i].think(floor, &count_floor[0]);
      if (debug==1) printf ("Message received - length : %d\n",result[0]);
      if (debug==1) if (result[0]>0) printf("         X= %d  Y= %d  CODE= %d\n",result[1],result[2],result[3]);
      process(result); // process result - delete food and add esthers
      return;
    }
}

#ifndef _Walk_
#define _Walk_

#include "nest.h"

class Walk {

  public:
  Walk();
  ~Walk(void);
  void Walk::init_map();
  void Walk::dump_map();
  void Walk::dump_pop();
  void Walk::evaporate(int);
  void Walk::activate(int);
  void Walk::asleep(int);
  void Walk::decimate();
  void Walk::process(int *);
  void Walk::create();
  void Walk::feed();
  void Walk::update();
  void Walk::think();
  void Walk::move();

 private:
  FILE *map_initf;
  FILE *antsf, *statf, *mapf;
  int *floor; // table of floor coords (wall , food , esthers and nests)
  int count_floor[4]; // [ length of floor; stock of wall on the floor; stock of food on the floor ; stock of esther on the floor]
  Nest *nests;
  int *result;

  friend class Nest;

};

#endif

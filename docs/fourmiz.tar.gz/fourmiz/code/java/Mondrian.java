//Draw a rectangle

import java.applet.*;    
import java.awt.*; 

public class Mondrian1 extends Applet {

  int height, width;

  public void init() {
  
    Dimension d = size();
    height = d.height;
    width = d.width;
    repaint();

  }

  public void paint(Graphics g) {

    g.drawRect(0, 0, width, height);
    
  }

}

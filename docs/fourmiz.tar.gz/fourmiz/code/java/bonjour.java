import java.awt.*;
import java.applet.*;
import java.lang.*;

public class bonjour extends Applet {
    String msg;
    
    public void init() {
	msg="Bonjour de java !";
    }
    
    public void paint(Graphics g) {
	
	//ciel
	g.setColor(Color.blue);
	g.fillRect(0,0,300,110);
	//prairie
	g.setColor(Color.green);
	g.fillRect(0,110,300,90);
	//soleil
	g.setColor(Color.yellow);
	g.fillOval(220,20,30,30);
    }
    
}

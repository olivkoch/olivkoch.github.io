import java.awt.*;
import java.applet.*;

public class cible extends Applet {

 public void init() {
  setBackground(Color.white);
 }
 
 public void paint(Graphics g) {
  int dec=30;
  int cote=Math.min(getSize().width,getSize().height)-dec;
  int x=(getSize().width-cote)/2;
  int y=(getSize().height-cote)/2;
  g.setColor(Color.yellow);
  while (cote>=dec) {
   if (g.getColor()==Color.yellow) g.setColor(Color.red);
   else g.setColor(Color.yellow);
   g.fillOval(x,y,cote,cote);
   cote=cote-dec;
   x=x+dec/2;
   y=y+dec/2;
  }
 }
 
}

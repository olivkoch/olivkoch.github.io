// definition of constant parameters

const int size_x = 320;       // size of window <unit : pixels>
const int size_y = 240;       // size of window <unit : pixels>
const int exp_of_life = 1000;  // ants expect of life
const int colony=400;         // number of ants at start
const int hunger_limit=1000;    // time limit before starve death
const int miles_limit=1000;   // miles limit before death
const int price_of_life=5;    // food payed for each ant created
const int pop_limit=600;      // max number of ants per nest
const int num_nests=5;        // number of nets
const int prob_left=1;        // left handed tendency (out of 10)
const int prob_right=9;       // right handed tendency (out of 10)
const int tactivate=10;       // time delay between two 'awaking/sleeping ants'
const int tdump=10;           // time delay between two map dumps
const int debug=0;            // enable/disable debugging printf

// important :
// colony < pop_limit !!!

#include <stdio.h>
#include <iostream.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "Pot.h"
#include "Brique.h"
#include "Lot.h"

int main(void) {

	Pot p1(1.0,"vert","laque",68.30);
	Pot p2(0.5,"beige","mate",40.50);
	Pot p3(2.0,"bleu","brillante",130.00);
	
	Brique b1(0.3,"rouge",5.0,15.0,7.0,30.00);
	Brique b2(0.3,"jaune",10.0,30.0,20.0,50.00);
	Brique b3(0.3,"gris",25.0,50.0,5.0,80.00);
	
	Lot l1(2, b1,3, p1);
        l1.affiche();
}

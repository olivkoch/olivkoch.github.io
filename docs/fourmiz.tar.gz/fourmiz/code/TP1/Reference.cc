#include <stdio.h>
#include <iostream.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "Reference.h"

int nombre = 0;

Reference::Reference(void){
	nombre++;
	id = nombre;
	prix = 0.;
#ifdef DEBUG
	fprintf(stdout,"Appel au constructeur sans argument pour la r�f�rence %i.\n",id);
#endif
}

Reference::Reference(double px){
	nombre++;
	id = nombre;
	prix = pds;
#ifdef DEBUG
	fprintf(stdout,"Appel au constructeur avec arguments pour la r�f�rence %i.\n",id);
#endif
}

Reference::Reference(const Reference& ref){
	nombre++;
	id = nombre;
	prix = ref.prix;
#ifdef DEBUG
	fprintf(stdout,"Appel au constructeur de recopie pour la r�f�rnce %i.\n",id);
#endif
}

Reference::~Reference(void){
#ifdef DEBUG
	fprintf(stdout,"Appel au destructeur sur la r�f�rence %i.\n",id);
#endif	
}

void Reference::affiche(void){
        fprintf(stdout,"R�f�rence %i de prix %f Euros.\n",id, prix);
}

int Reference::getId(void){
	return(id);
}

double Reference::getPrix(void){
	return(prix);
}

void Reference::setPrix(double px){
	prix = px
}

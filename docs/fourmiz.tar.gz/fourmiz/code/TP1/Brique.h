#ifndef _Brique_
#define _Brique_


#include "Objet.h"

class Brique : public Objet {

protected :
	double    hauteur;
	double    largeur;
	double profondeur;
	double       prix;
	
public :
	Brique::Brique(double pds, char* col, double htr, double lar, double pro, double pri);
	double donnePrix(void);
	void   affiche(void);
};

#endif

#include <stdio.h>
#include <iostream.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "Objet.h"

Objet o1;

void test1(void){
	Objet o2;
}

void test2(void){
        Objet* o = new Objet;
}

int main(void) {
        Objet o2;
		
	test1();
	test2();
};

#include <stdio.h>
#include <iostream.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "Pot.h"

Pot::Pot(double pds, char* col, char* typ, double prx):Objet(col,pds){
	type = new char[strlen(typ)+1];
	strcpy(type,typ);
	prix = prx;
#ifdef DEBUG
	cout << "Appel au constructeur avec arguments sur Pot." << endl;
#endif
}

double Pot::donnePrix(void){
	return prix;
}

void Pot::affiche(void){
	Objet::affiche();
	cout << "Ce pot de peintue " << type << " co�te " << prix << " Francs." << endl;
}

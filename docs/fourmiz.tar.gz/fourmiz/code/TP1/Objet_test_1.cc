#include <stdio.h>
#include <iostream.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "Objet.h"

int main(void) {
	
	Objet o1("objet1",1.0);
	o1.affiche();
        o1.setColor("Nouvelle couleur 1");
        o1.setPoids(6.55957);
        o1.affiche();

	Objet* o2 = new Objet ("Objet 2",1.0);
	o2->affiche();
        o2->setColor("Nouvelle couleur 2");
        o2->setPoids(6.55957);
        o2->affiche();
        delete(o2);

        Objet o3;
        o3.affiche();
        o3.setColor("Nouvelle couleur 3");
        o3.setPoids(6.55957);
        o3.affiche();

        Objet* o4 = new Objet;
	o4->affiche();
        o4->setColor("Nouvelle couleur 4");
        o4->setPoids(6.55957);
        o4->affiche();
        delete(o4);
};

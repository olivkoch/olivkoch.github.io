#ifndef _Pot_
#define _Pot_

#include "Objet.h"

class Pot : public Objet {

protected :
	char*   type;
	double  prix;
	
public :
	Pot::Pot(double pds, char* col, char* typ, double prx);
	double donnePrix(void);
	void   affiche(void);
};

#endif

#ifndef _Lot_
#define _Lot_

class Pot;
class Brique;

class Lot {

protected :
	int        nb_pots;
	Pot&           pot;
	int     nb_briques;
	Brique&     brique;
	float         prix;
	
public :
	Lot(int nb_briques, Brique& brq, int nb_pots, Pot& pot);

	void   affiche(void);
};

#endif

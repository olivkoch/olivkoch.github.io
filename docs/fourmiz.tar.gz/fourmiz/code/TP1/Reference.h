#ifndef _Reference_
#define _Reference_

class Reference {

private :
	static int number;

protected :
	int            id;
	double       prix;
	
public :
	Reference (void);
        Reference (double px);
        Reference (const Reference& ref);
        ~Reference (void);

	int    getId(void);
	double getPrix(void);
	void   setPrix(double px);
	
	void   affiche(void);
};

#endif

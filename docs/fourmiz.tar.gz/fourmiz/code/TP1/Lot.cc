#include <stdio.h>
#include <iostream.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "Lot.h"
#include "Pot.h"
#include "Brique.h"

#define DEBUG
Lot::Lot(int nbriq, Brique& brq, int npots, Pot& pt): brique(brq),pot(pt){
	
	nb_pots    = npots;
	nb_briques = nbriq;
	
	prix = 0.9*(npots * (brq.donnePrix()) + nbriq * (pt.donnePrix()));

	
#ifdef DEBUG
	cout << "Appel au constructeur avec arguments sur Lot." << endl;
#endif
}

void Lot::affiche(void){
	cout << "Ce lot contient " << nb_pots << " pots et " << nb_briques << " briques et co�te " << prix << " Francs." << endl;
	cout << "Description d�taill�e : " << endl;
	pot.affiche();
	
}

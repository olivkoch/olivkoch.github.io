#include <stdio.h>
#include <iostream.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "Objet.h"

void test(Objet o){
	o.affiche();
	o.setPoids(3.1415);
	o.setColor("Blue");
	o.affiche();
}

int main(void) {
	Objet o1("Rouge", 2.7128);
        test(o1);
        o1.affiche();
}

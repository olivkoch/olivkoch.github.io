#include <stdio.h>
#include <iostream.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "Brique.h"

Brique::Brique(double pds, char* col, double htr, double lar, double pro, double prx):Objet(col,pds){
	hauteur = htr;
	largeur = lar;
	profondeur = pro;
	prix = prx;
#ifdef DEBUG
	cout << "Appel au constructeur avec arguments sur Brique." << endl;
#endif
}

double Brique::donnePrix(void){
	return prix;
}

void Brique::affiche(void){
	Objet::affiche();
	cout << "Cet brique de dimensions " << hauteur << " cm x " << largeur << " cm x " << profondeur << " cm co�te " << prix << " Euros." << endl;
}

#include <stdio.h>
#include <iostream.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "Objet.h"

Objet Tableau1[4];

void test(void){
	Objet* Tableau3 = new Objet[4];
	delete[] Tableau3;
}

int main(void) {
        Objet Tableau2[4];
		
	test();
};

#include <stdio.h>
#include <iostream.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "Objet.h"

int nombre = 0;

Objet::Objet(void){
	nombre++;
	id = nombre;
	couleur = NULL;
	poids = 0.;
#ifdef DEBUG
	cout << "Appel au constructeur sans argument pour l'objet " << id << endl;
#endif
}

Objet::Objet(char* color,double pds){
	nombre++;
	id = nombre;
	couleur = new char[sizeof(color)];
	strcpy(couleur,color);
	poids = pds;
#ifdef DEBUG
	cout << "Appel au constructeur avec arguments pour l'objet " << id << endl;
#endif
}

Objet::Objet(const Objet& objet){
	nombre++;
	id = nombre;
	couleur = new char[sizeof(objet.couleur)];
	strcpy(couleur,objet.couleur);
	poids = objet.poids;
#ifdef DEBUG
	cout << "Appel au constructeur de recopie pour l'objet " << id << endl;
#endif
}

Objet::~Objet(void){
	delete couleur;
#ifdef DEBUG
	cout << "Appel au destructeur sur l'objet " << id << endl;
#endif	
}

void Objet::affiche(void){
        fprintf(stdout,"Je suis l'objet %i de couleur %s et de poids %f kg.\n",id, couleur, poids);
}

int Objet::getId(void){
	return(id);
}

char* Objet::getColor(void){
	return(couleur);
}

void Objet::setColor(char* color){
	if(couleur){
		delete[] couleur;
	}
	couleur = new char[strlen(color)+1];
	strcpy(couleur,color);
}

double Objet::getPoids(void){
	return(poids);
}

void Objet::setPoids(double pds){
	poids = pds;
}


#ifndef _Objet_
#define _Objet_

class Objet {

private :
	static int number;

protected :
	int            id;
	char*     couleur;
	double      poids;
	
public :
	Objet  (void);
        Objet  (char* color,double pds);
        Objet  (const Objet& objet);
        ~Objet (void);

	int    getId(void);
	char*  getColor(void);
	void   setColor(char* color);
	double getPoids(void);
	void   setPoids(double pds);
	
	void   affiche(void);
};

#endif

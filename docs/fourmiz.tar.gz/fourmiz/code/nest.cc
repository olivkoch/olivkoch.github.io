#include "nest.h"

int Nest::sign(int r) {
  if (r > 0) return 1;
  else if (r < 0) return -1;
  else return 0;
}

Nest::Nest(int *floor, int* count_floor) {

  population = colony;
  // randomize nest position
  tv = new struct timeval;
  tz = new struct timezone;
  timeofday = gettimeofday(tv,tz);
  srand(getpid()*(tv->tv_usec));
  xn = rand()%size_x;
  yn = rand()%size_y; 
  // loop while the nest is on a wall, food, or esther
  // usually, the first nest chosen is okay - and loop isn't executed
  while ( get_map(xn, yn, floor, count_floor[0]) > 0 ) {
    if (debug==1) printf("   --- Collision : X=%d, Y=%d, M=%d\n",xn,yn,get_map(xn, yn, floor, count_floor[0]));
    xn = rand()%size_x;
    yn = rand()%size_y; 
}
  if (debug==1) printf("Creating nest at X=%d Y=%d, M=%d\n",xn,yn,get_map(xn, yn, floor, count_floor[0]));
  ants=new Ant[pop_limit];          // creates nest population
  for (int i=0;i<colony;i++)        // initializes ants birth place
    {
      ants[i].xborn=xn; ants[i].yborn=yn; ants[i].x=xn; ants[i].y=yn; 
      ants[i].nx=xn+(rand()%2-1)*2+1; 
      ants[i].ny=yn+(rand()%2-1)*2+1; 
      ants[i].id=i;
    }
  return;
}

Nest::~Nest() {

  //cout << "killing nest\n";
  delete[] ants;
  return;
}

int Nest::get_map(int x, int y, int *map, int length) {

  for (int m=0;m<length;m++) 
    {
      if (map[3*m] != x) continue;
      if (map[3*m+1] == y) return map[3*m+2];
    }  
  return 0;
}

void Nest::activate() {
  
  for (int i=0;i<population;i++)
    {
      if (ants[i].state == 3) 
	{                     // wakes up 1 sleeping ant out of 10
	  if (rand()%(200*pop_limit) == 0) 
	    {
	      ants[i].state = 0; 
	      printf("\nAnt activated !\n");
	    }
	}
    }
  return;
}

void Nest::asleep() {
for (int i=0;i<population;i++)
    {
      if (ants[i].state <= 1) 
	{                 // asleeps 1 sleeping ant out of 10
	  if (rand()%(500*pop_limit) == 0) 
	    {
	      ants[i].state = 3;
	      printf("\nAnt aslept...\n");
	    }
	}
    }
 return;
}


void Nest::dump_pop() {
if ( (antsf = fopen("./files/ants","a+")) == NULL )  // opening file ants
    cout <<  "**ERROR : opening ./files/ants\n";    
for (int i=0;i<population;i++)
    {
      fprintf (antsf, "%d %d %d\n",ants[i].state, ants[i].x, ants[i].y);
    }
 fclose(antsf);
 return;
}

void Nest::kill(int i, int code) {

  printf("\nkilling ant Code %d\n",code);
  if (i < pop_limit-1)
  for (int j=i;j<pop_limit-1;j++) ants[j]=ants[j+1];
  population--;
  
}

void Nest::decimate() {
  for (int i=0;i<population;i++)
    {
      if (ants[i].age > exp_of_life) kill(i,1); // too old ants die
      if (rand()%(500*pop_limit) == 0) kill(i,2); // chance kills 1 ant out of 1000
      if (ants[i].hunger > hunger_limit) kill(i,3); // too hungry ants die
      if (ants[i].miles > miles_limit) kill(i,4); // too tired ants die

    }
}

void Nest::create() {
  while (stock > 5) {
    if (population < pop_limit) {   // creation of ants allowed
    population++;
    stock = stock-5;
    printf("\nAnt born in nest %d %d\n",xn,yn);
    ants[population].miles = 0;  // initializing ant
    ants[population].age = 0;
    ants[population].hunger = 0;
    ants[population].xborn=xn;
    ants[population].yborn=yn;
    tv = new struct timeval;
    tz = new struct timezone;
    timeofday = gettimeofday(tv,tz);
    srand(getpid()*(tv->tv_usec));
    ants[population].state = 0;
    ants[population].hand = rand()%2;
    for (int m=0;m<9;m++) ants[population].field[m]=0;
    }
  }
  return;
}

void Nest::feed() {
 for (int i=0;i<population;i++)
    {
      if ( (ants[i].hunger > hunger_limit*2/3 )&&(ants[i].state == 2) )
	{ // here : ant is hungry and avoid death by eating the food she was bringing back home
	  printf("Ant eats...\n");
	  ants[i].hunger = 0;
	  ants[i].state = 0;
	}
    }
 return;
}

void Nest::update() {
for (int i=0;i<population;i++)
    {
      ants[i].age++;
      ants[i].hunger++;
      if ( ants[i].state <=2 ) ants[i].miles++;
    }
 return;
}

void Nest::move() {
  int dx, dy;
for (int i=0;i<population;i++)
  {
    dx = ants[i].nx-ants[i].x;
    dy = ants[i].ny-ants[i].y;
    ants[i].x = ants[i].nx;
    ants[i].y = ants[i].ny;
    ants[i].nx = ants[i].x+dx;
    ants[i].ny = ants[i].y+dy;
    if (debug==1) printf("     Ant moved to %d %d\n",ants[i].x,ants[i].y);
  }
 return;
}

void Nest::look(int *floor, int *count_floor) {
  int dx, dy;
  int i,j; 
  for (int k=0;k<population;k++)
    {
      // ants looking at its neighbourhood (updating field)
      
      // first : look straight forward
      dx = ants[k].nx-ants[k].x;
      dy = ants[k].ny-ants[k].y;
      ants[k].field[3]=ants[k].nx;
      ants[k].field[4]=ants[k].ny;
      ants[k].field[5]=get_map(ants[k].nx, ants[k].ny, floor, count_floor[0]); 

      // second : look right
      i = ants[k].x+sign(dx+dy);
      j = ants[k].y+sign(dy-dx);
      ants[k].field[6]=i;
      ants[k].field[7]=j;
      ants[k].field[8]=get_map(i,j, floor, count_floor[0]); 

      // third : look left
      i = ants[k].x+sign(dx-dy);
      j = ants[k].y+sign(dx+dy);
      ants[k].field[0]=i;
      ants[k].field[1]=j;
      ants[k].field[2]=get_map(i,j, floor, count_floor[0]); 

    }
  return;
  
}

int* Nest::think(int *floor, int *count_floor) {

  int *r;
  int count=0;
  r = new int[3];
  int* message = new int[3*population+1];

  for (int i=0;i<population;i++)
  {
    // for each ant : thinking where to go according to the field
    r = ants[i].think(floor, count_floor);
    ants[i].nx = r[0];
    ants[i].ny = r[1];
    // if r[2] = 1 estherize
    // if r[2] = 2 delete food
    // if r[2] = 3 add found in stock
    if (r[2]==3) 
      { 
	stock++; 
	if (debug==1) printf("                                                    STOCK %d\n",stock);
      }
    message[3*i+1]=r[0];
    message[3*i+2]=r[1];
    message[3*i+3]=r[2];
    if (r[2]>0) count++;
  }
  message[0]=count;
  return message;
}



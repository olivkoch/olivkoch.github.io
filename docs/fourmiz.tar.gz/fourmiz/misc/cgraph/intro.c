#include"graphics.h"
#include"conio.h"
#include"stdlib.h"
#include"stdio.h"

char *dname[]={"detection demand�e","CGA","MCGA","EGA","64 K EGA",
"monochrome EGA","IBM 8514","Hercule monochrome","AT&T 6300 PC",
"VGA","IBM 3270 PC"};

int main (void)
        {
        int     gdriver,
                gmode,
                errorcode;

        detectgraph(&gdriver,&gmode);
        errorcode=graphresult();

        if (errorcode!=grOk)
                {
                printf ("Graph error : %s\n",grapherrormsg(errorcode));
                printf ("Press");
                getch();
                exit(1);
                }

        clrscr();
        printf("Votre carte est du type %s, vous en avez de la chance!\n",dname[gdriver]);
        printf("\nAppuyez sur une touche...");
        getch();
        return 0;
}

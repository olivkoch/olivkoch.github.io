/*****************************************************************************
									     
			 Biblioth�que graphique

			 Steve OUDOT - juin 1999

******************************************************************************/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xos.h>
#include <X11/Xatom.h>
#include <X11/keysym.h>
#include <stdio.h>

typedef XImage* image;

#define ligne(x1,y1,x2,y2) XDrawLine (display,win,gc,x1,y1,x2,y2)
#define allumer_pixel(x,y) XDrawPoint (display,win,gc,x,y)
#define liberer_image(image) XDestroyImage(image)
#define dessiner_rectangle(x1,y1,x2,y2) XDrawRectangle(display,win,gc,x1,y1,x2-x1,y2-y1)

Display *display;
int screen;
Colormap cmap;
GC gc;
XFontStruct *font=NULL; // Police par d�faut
long translate[256];  //Nouvelle palette
int fillcolor=0,forecolor=0; // couleur de remplissage et de dessin
Window win;   // Notre fen�tre graphique
int width,height;

#define NBRE_COULEURS 16  // le nombre de couleurs disponibles

#define C_BLANC            0
#define C_BLEU             1
#define C_VERT             2
#define C_CYAN             3
#define C_ROUGE            4
#define C_MAGENTA          5
#define C_MARRON           6
#define C_GRIS             7
#define C_GRIS_CLAIR       8
#define C_BLEU_CLAIR       9
#define C_VERT_CLAIR       10
#define C_CYAN_CLAIR       11
#define C_ROUGE_CLAIR      12
#define C_MAGENTA_CLAIR    13
#define C_JAUNE            14
#define C_NOIR             15




void fermer_graphisme()
  {
    XUnloadFont (display,font->fid);
    XFreeGC (display,gc); 
    XCloseDisplay (display);
  } 


void forcer_affichage()
{
XFlush(display);
}

void dessiner_polygone(int nbpoints,int *points)
{
int polyi;
XPoint image[nbpoints+1];
for (polyi=0;polyi<nbpoints;polyi++)
   {
   image[polyi].x=*points;
   points++;
   image[polyi].y=*points;
   points++;
   };
image[polyi].x=image[0].x;
image[polyi].y=image[0].y;
XDrawLines(display,win,gc,(XPoint *)image,nbpoints+1,CoordModeOrigin);
}


void remplir_polygone(int nbpoints,int *points)
{
int polyi;
XPoint image[nbpoints+1];
for (polyi=0;polyi<nbpoints;polyi++)
   {
   image[polyi].x=*points;
   points++;
   image[polyi].y=*points;
   points++;
   };
image[polyi].x=image[0].x;
image[polyi].y=image[0].y;
XSetForeground (display,gc,translate[fillcolor]);
XFillPolygon(display,win,gc,(XPoint *)image,nbpoints+1,Nonconvex,CoordModeOrigin);
XSetForeground (display,gc,translate[forecolor]);
XDrawLines(display,win,gc,(XPoint *)image,nbpoints+1,CoordModeOrigin);
}


void remplir_rectangle(int x1,int y1,int x2,int y2)
{
int image[8],saveforecolor=fillcolor;
image[0]=x1;
image[1]=y1;
image[2]=x2;
image[3]=y1;
image[4]=x2;
image[5]=y2;
image[6]=x1;
image[7]=y2;
forecolor=fillcolor;
remplir_polygone(4,&image[0]);
forecolor=saveforecolor;
}


void couleur_remplissage(int color)
{
fillcolor=color;
}

void couleur_dessin(int colori)
{
forecolor=colori;
XSetForeground (display,gc,translate[colori]);
}


int saisir_pixel(int x,int y)
{
unsigned long pixel;
int pixeli;
XImage *image=XGetImage(display,win,x,y,x+1,y+1,AllPlanes,ZPixmap);
pixel=XGetPixel(image,0,0);
XDestroyImage(image);
for (pixeli=0;pixeli<256;pixeli++) if (translate[pixeli]==pixel) return(pixeli);
return(0);
}


void afficher_image(XImage *image,int x,int y,int l_x,int l_y)
{
XPutImage(display,win,gc,image,0,0,x,y,l_x,l_y);
}


XImage *saisir_image(int x,int y,int l_x,int l_y)
{
return(XGetImage(display,win,x,y,l_x,l_y,AllPlanes,ZPixmap));
}

void remplir_ellipse(int x,int y,int radiusx,int radiusy)
{
XSetForeground (display,gc,translate[fillcolor]);
XFillArc(display,win,gc,x-radiusx,y-radiusy,2*radiusx,2*radiusy,0,23040);
}

void dessiner_ellipse(int x,int y,int radiusx,int radiusy)
{
XSetForeground (display,gc,translate[forecolor]);
XDrawArc(display,win,gc,x-radiusx,y-radiusy,2*radiusx,2*radiusy,0,23040);
}


void afficher_texte(int x,int y,unsigned char *texte)
{
int texti;
for (texti=0;*texte!='\0';texti++) texte++;
texte-=texti;
XDrawString(display,win,gc,x,y,texte,texti);
}

void effacer_ecran()
{
int savefillcolor=fillcolor;
couleur_remplissage(C_BLANC);
remplir_rectangle(0,0,width-1,height-1);
fillcolor=savefillcolor;
}


void openwindow(char *winname, char *iconname,int size_x,int size_y,Window *window)
{
XColor xcolor,colorcell;
int font_height,font_width;
XSizeHints size_hints;
int darkcolor,lightcolor,black,white;

char *window_name = winname;
char *icon_name = iconname;
int windowwidth, windowheight;
Pixmap icon_pixmap;

#define icon_bitmap_width 16
#define icon_bitmap_height 16
   static unsigned char icon_bitmap_bits[] = {
	0x1f, 0xf8, 0x1f, 0x88, 0x1f, 0x88, 0x1f, 0x88, 0x1f, 0x88, 0x1f, 0xf8,
	0x1f, 0xf8, 0x1f, 0xf8, 0x1f, 0xf8, 0x1f, 0xf8, 0x1f, 0xf8, 0xff, 0xff,
	0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff};


screen = DefaultScreen (display);
cmap = DefaultColormap (display, screen);
darkcolor =black = BlackPixel (display, screen);
lightcolor =white = WhitePixel (display, screen);
translate[15]=black;
translate[0]=white;

// D�finition de la palette :

if (XAllocNamedColor(display,cmap,"blue",&colorcell,&xcolor))
              translate[1]=colorcell.pixel;
if (XAllocNamedColor(display,cmap,"green3",&colorcell,&xcolor))
              translate[2]=colorcell.pixel;
if (XAllocNamedColor(display,cmap,"turquoise3",&colorcell,&xcolor))
              translate[3]=colorcell.pixel;
if (XAllocNamedColor(display,cmap,"red2",&colorcell,&xcolor))
              translate[4]=colorcell.pixel;
if (XAllocNamedColor(display,cmap,"magenta3",&colorcell,&xcolor))
              translate[5]=colorcell.pixel;
if (XAllocNamedColor(display,cmap,"chocolate3",&colorcell,&xcolor))
              translate[6]=colorcell.pixel;
if (XAllocNamedColor(display,cmap,"DarkGray",&colorcell,&xcolor))
              translate[7]=colorcell.pixel;
if (XAllocNamedColor(display,cmap,"LightGray",&colorcell,&xcolor))
              translate[8]=colorcell.pixel;
if (XAllocNamedColor(display,cmap,"RoyalBlue",&colorcell,&xcolor))
              translate[9]=colorcell.pixel;
if (XAllocNamedColor(display,cmap,"green1",&colorcell,&xcolor))
              translate[10]=colorcell.pixel;
if (XAllocNamedColor(display,cmap,"turquoise1",&colorcell,&xcolor))
              translate[11]=colorcell.pixel;
if (XAllocNamedColor(display,cmap,"red1",&colorcell,&xcolor))
              translate[12]=colorcell.pixel;
if (XAllocNamedColor(display,cmap,"magenta1",&colorcell,&xcolor))
              translate[13]=colorcell.pixel;
if (XAllocNamedColor(display,cmap,"Yellow",&colorcell,&xcolor))
              translate[14]=colorcell.pixel;


    windowwidth=size_x;
    windowheight=size_y;
    *window=XCreateSimpleWindow(display,RootWindow(display,screen),0,0,windowwidth,windowheight,0,0,lightcolor);

    icon_pixmap=XCreateBitmapFromData(display,*window,
	icon_bitmap_bits,icon_bitmap_width,icon_bitmap_height);

    size_hints.flags=PPosition | PSize | PMinSize | PMaxSize;
    size_hints.min_width=size_x;
    size_hints.min_height=size_y;
    size_hints.max_width=size_x;
    size_hints.max_height=size_y;


  {
  XWMHints wm_hints;
  XClassHint class_hints;
  XTextProperty windowName, iconName;
  if (XStringListToTextProperty(&window_name,1,&windowName)==0)
   {fprintf(stderr,"Error: Structure allocation for windowName failed.\n");
    exit(-1);
   }
  if (XStringListToTextProperty(&icon_name,1,&iconName)==0)
   {fprintf(stderr,"Error: Structure allocation for iconName failed.\n");
    exit(-1);
   }
  wm_hints.initial_state=NormalState;
  wm_hints.input=True;
  wm_hints.icon_pixmap=icon_pixmap;
  wm_hints.flags=StateHint|IconPixmapHint|InputHint;
  class_hints.res_class="Basicwin";
XSetWMProperties(display,*window,&windowName,&iconName,NULL,0,&size_hints,&wm_hints,&class_hints);

 if ((font=XLoadQueryFont(display,"8x8"))==NULL)
 if ((font=XLoadQueryFont(display,"fixed"))==NULL)
     {
      fprintf(stderr," Erreur: Impossible d'allouer la police de caract�res.\n");
      exit(-1);
     }

 font_height=font->ascent+font->descent;
 font_width=font->max_bounds.width;
 }

    gc=XCreateGC(display,*window,0,NULL);
    XSetFont(display,gc,font->fid);
    XSetForeground(display,gc,black);
    XSetBackground(display,gc,lightcolor); 
}


void initialiser_graphisme(int winwidth,int winheight)

  {
char *display_name=NULL;
XSetWindowAttributes winatt;

if ((display=XOpenDisplay(display_name))==NULL)
   {
   fprintf(stderr,"Erreur: impossible d'ouvrir le Display : %s\n",XDisplayName(display_name));
   exit(-1);
   }

fprintf(stderr,"\n Cr�ation de la fen�tre graphique...");

width=winwidth;
height=winheight;
openwindow ("Fenetre graphique", "Fenetre graphique",width,height,&win);

winatt.backing_store=WhenMapped;
XChangeWindowAttributes(display,win,CWBackingStore,&winatt);

XMapWindow(display,win);
XFlush(display);
fprintf(stderr," appuyez sur une touche pour continuer\n");
getchar();
}


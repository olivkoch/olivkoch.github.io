#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <graphisme.h>




int main()
{

/*D�finition des donn�es*/

int i,j;
XImage *mon_image;
int cube[8][2]={
  {100,100},
  {200,100},
  {200,200},
  {100,200},
  {125,175},
  {225,175},
  {225,75},
  {125,75}
};

int faces[3][8]={
  {100,100,
  200,100,
  200,200,
  100,200},

  {100,100,
   125,75,
   225,75,
   200,100},

  {200,100,
   225,75,
   225,175,
   200,200}
};

int r[400],teta[400];
int plus_r[400],plus_teta[400];

/*Fin de d�finition des donn�es*/



/*On initialise le graphisme (obligatoire)*/
initialiser_graphisme(400,400);



/*On dessine d'abord des rectangles de toutes les couleurs*/
fprintf(stderr,"\n\nUtilisation de la fonction dessiner_rectangle");

for (i=0;i<NBRE_COULEURS;i++)
  {
    couleur_dessin(i);
    dessiner_rectangle(20*i,0,20*i+19,399);
  }
forcer_affichage();
fprintf(stderr,"\n Attendez 2 secondes...");
sleep(2);
fprintf(stderr," Ok");

/*Ensuite on les remplit*/
fprintf(stderr,"\n\nUtilisation de la fonction remplir_rectangle");

for (i=0;i<NBRE_COULEURS;i++)
  {
    couleur_remplissage(i);
    remplir_rectangle(20*i,0,20*i+19,399);
  }
forcer_affichage();
fprintf(stderr,"\n Appuyez sur <Return>...");
getchar();
fprintf(stderr," Ok");

/*On efface l'�cran*/
effacer_ecran();

/*On dessine des ellipses pleines vertes*/
fprintf(stderr,"\n\nUtilisation de la fonction remplir_ellipse");

couleur_remplissage(C_VERT);
for (i=1;i<20;i++)
  {
    remplir_ellipse(20*i,20*i,20,10);
    remplir_ellipse(400-20*i,20*i,20,10);
  }
forcer_affichage();
fprintf(stderr,"\n Attendez 2 secondes...");
sleep(2);
fprintf(stderr," Ok");

/*On dessine des contours d'ellipses bleus*/
fprintf(stderr,"\n\nUtilisation de la fonction dessiner_ellipse");

couleur_dessin(C_BLEU_CLAIR);
for (i=1;i<20;i++) 
  {
    dessiner_ellipse(20*i,20*i,20,10);
    dessiner_ellipse(400-20*i,20*i,20,10);
  }
forcer_affichage();
fprintf(stderr,"\n Appuyez sur <Return>...");
getchar();
fprintf(stderr," Ok");

/*On efface l'�cran*/
effacer_ecran();

/*On dessine un cube petit-�-petit, avec la fonction "ligne"*/
fprintf(stderr,"\n\nUtilisation de la fonction ligne");

couleur_dessin(C_ROUGE);
for (i=0;i<7;i++) 
  {
    ligne(cube[i][0],cube[i][1],cube[i+1][0],cube[i+1][1]);
    forcer_affichage();
    usleep(200000);
  }
ligne(cube[0][0],cube[0][1],cube[7][0],cube[7][1]);
forcer_affichage();
usleep(200000);
ligne(cube[1][0],cube[1][1],cube[6][0],cube[6][1]);
forcer_affichage();
usleep(200000);
ligne(cube[2][0],cube[2][1],cube[5][0],cube[5][1]);
forcer_affichage();
usleep(200000);
ligne(cube[0][0],cube[0][1],cube[3][0],cube[3][1]);
forcer_affichage();
usleep(200000);
ligne(cube[4][0],cube[4][1],cube[7][0],cube[7][1]);
forcer_affichage();

fprintf(stderr,"\n Attendez 2 secondes...");
sleep(2);
fprintf(stderr," Ok");


/*On remplit les faces int�ressantes*/
fprintf(stderr,"\n\nUtilisation de la fonction remplir_polygone");

couleur_remplissage(C_NOIR);
remplir_polygone(4,faces[0]);

couleur_remplissage(C_GRIS);
remplir_polygone(4,faces[1]);

couleur_remplissage(C_GRIS_CLAIR);
remplir_polygone(4,faces[2]);

forcer_affichage();
fprintf(stderr,"\n Appuyez sur <Return>...");
getchar();
fprintf(stderr," Ok");


/*Maintenant on va dupliquer ce cube en copiant son image*/
fprintf(stderr,"\n\nUtilisation de la fonction saisir_image");

mon_image=saisir_image(100,75,126,126);

fprintf(stderr,"\nUtilisation de la fonction afficher_image");

/*On efface l'�cran*/
effacer_ecran();

afficher_image(mon_image,0,0,126,126);
afficher_image(mon_image,274,0,126,126);
afficher_image(mon_image,0,274,126,126);
afficher_image(mon_image,274,274,126,126);
afficher_image(mon_image,137,137,126,126);


fprintf(stderr,"\nUtilisation de la fonction liberer_image");

liberer_image(mon_image); //On lib�re ensuite la structure en m�moire
forcer_affichage();

fprintf(stderr,"\n Appuyez sur <Return>...");
getchar();
fprintf(stderr," Ok");


/*Une petite animation avec des allumages de pixels...*/
fprintf(stderr,"\n\nUtilisation de la fonction allumer_pixel");

/*On se met un fond noir*/
couleur_remplissage(C_NOIR);
remplir_rectangle(0,0,399,399);

/*On initialise les coordonn�es des points*/ 
for (j=0;j<200;j++)
  {
    r[j]=j;
    plus_r[j]=1;
    teta[j]=360-j;
    plus_teta[j]=5;
  }
for (j=0;j<200;j++)
  {
    r[200+j]=j;
    plus_r[200+j]=1;
    teta[200+j]=j;
    plus_teta[200+j]=5;
  }


for (i=0;i<1000;i++)
  {
    for (j=0;j<400;j++)
      {
	/*On efface l'ancien point, ie on le met � la couleur du fond (noir)*/
	couleur_dessin(C_NOIR);
	allumer_pixel(200+r[j]*cos(M_PI*teta[j]/180),200+r[j]*sin(M_PI*teta[j]/180));

	/*On d�termine le nouveau point*/
	r[j]+=plus_r[j];
	teta[j]+=plus_teta[j];
	
	/*On affiche le nouveau point*/
	couleur_dessin(C_BLANC);
        allumer_pixel(200+r[j]*cos(M_PI*teta[j]/180),200+r[j]*sin(M_PI*teta[j]/180));

	/*On v�rifie que tout se passera bien au prochain tour*/
	if (r[j]+plus_r[j]<0 || r[j]+plus_r[j]>=200) plus_r[j]=-plus_r[j];
	if (teta[j]+plus_teta[j]>=360) teta[j]-=360;

      }

  /*On force la synchronisation*/
  forcer_affichage();
  /*On se laisse un petit d�lai avant la prochaine boucle*/
  usleep(10000);
  }

fprintf(stderr,"\n Appuyez sur <Return>...");
getchar();
fprintf(stderr," Ok");


/*On remet l'�cran noir*/
couleur_remplissage(C_NOIR);
remplir_rectangle(0,0,399,399);

/*On affiche du texte*/
fprintf(stderr,"\n\nUtilisation de la fonction afficher_texte");

couleur_dessin(C_GRIS);
for (i=0;i<4;i++)
  {
    afficher_texte(175,30*i+25,"THE END");
    forcer_affichage();
    usleep(300000);
  }
couleur_dessin(C_GRIS_CLAIR);
for (i=4;i<8;i++)
  {
    afficher_texte(175,30*i+25,"THE END");
    forcer_affichage();
    usleep(300000);
  }
couleur_dessin(C_BLANC);
for (i=8;i<12;i++)
  {
    afficher_texte(175,30*i+25,"THE END");
    forcer_affichage();
    usleep(300000);
  }

fprintf(stderr,"\n Appuyez sur <Return>...");
getchar();
fprintf(stderr," Ok");

/*On ferme la fen�tre graphique*/
fermer_graphisme();

printf("\n\n\n THE END\n\n");
return(0);
}


/*****************************************************************************
									     
			 Biblioth�que graphique

			 Steve OUDOT - juin 1999

******************************************************************************/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xos.h>
#include <X11/Xatom.h>
#include <X11/keysym.h>
#include <stdio.h>


#define ligne(x1,y1,x2,y2) XDrawLine (display,win,gc,x1,y1,x2,y2)
#define allumer_pixel(x,y) XDrawPoint (display,win,gc,x,y)
#define liberer_image(image) XDestroyImage(image)
#define dessiner_rectangle(x1,y1,x2,y2) XDrawRectangle(display,win,gc,x1,y1,x2-x1,y2-y1)


Display *display;
int screen;
Colormap cmap;
GC gc;
XFontStruct *font; // Police par d�faut
long translate[256];  //Nouvelle palette
int fillcolor,forecolor; // couleur de remplissage et de dessin
Window win;   // Notre fen�tre graphique
int width,height;


#define NBRE_COULEURS 16  // le nombre de couleurs disponibles

#define C_BLANC            0
#define C_BLEU             1
#define C_VERT             2
#define C_CYAN             3
#define C_ROUGE            4
#define C_MAGENTA          5
#define C_MARRON           6
#define C_GRIS             7
#define C_GRIS_CLAIR       8
#define C_BLEU_CLAIR       9
#define C_VERT_CLAIR       10
#define C_CYAN_CLAIR       11
#define C_ROUGE_CLAIR      12
#define C_MAGENTA_CLAIR    13
#define C_JAUNE            14
#define C_NOIR             15




void fermer_graphisme();

void forcer_affichage();

void dessiner_polygone(int nbpoints,int *points);

void remplir_polygone(int nbpoints,int *points);

void remplir_rectangle(int x1,int y1,int x2,int y2);

void couleur_remplissage(int color);

void couleur_dessin(int colori);

int saisir_pixel(int x,int y);

void afficher_image(XImage *image,int x,int y,int l_x,int l_y);

XImage *saisir_image(int x,int y,int l_x,int l_y);

void remplir_ellipse(int x,int y,int radiusx,int radiusy);

void dessiner_ellipse(int x,int y,int radiusx,int radiusy);

void afficher_texte(int x,int y,unsigned char *texte);

void effacer_ecran();

void openwindow(char *winname, char *iconname,int size_x,int size_y,Window *window);

void initialiser_graphisme(int winwidth,int winheight);
